import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Phone, CheckCircle, ArrowRight, MapPin, AlertTriangle, Plane, Building2, Home, Zap, Droplet, Star } from "lucide-react";
import { BE_CONFIG, beRoute } from "@/config/belgiumConfig";

const ZAVENTEM_WIJKEN = [
  { name: "Zaventem Centrum", slug: "zaventem", note: "Hoofdkantoor SOSPro.be", hq: true },
  { name: "Sterrebeek", slug: "sterrebeek", note: "Villa's & domotica" },
  { name: "Sint-Stevens-Woluwe", slug: "sint-stevens-woluwe", note: "Residentieel" },
  { name: "Nossegem", slug: "nossegem", note: "Nabij luchthaven" },
  { name: "Diegem", slug: "diegem", note: "Kantorenzone" },
  { name: "Melsbroek", slug: "melsbroek", note: "Militair vliegveld" },
  { name: "Kraainem", slug: "kraainem", note: "Grenst aan Brussel" },
  { name: "Machelen", slug: "machelen", note: "Bedrijvenzone" },
];

const ZAKELIJKE_SECTOREN = [
  { naam: "Kantoorgebouwen Luchthavenzone", icon: Building2, desc: "Spoedinterventies voor kantoorpanden langs de Leuvensesteenweg en rond Brussels Airport — buiten kantooruren mogelijk." },
  { naam: "Villa's & Residenties Sterrebeek", icon: Home, desc: "Domotica, zonnepanelen, laadpalen en hoogwaardige elektrische installaties in Sterrebeek en omgeving Evergempark." },
  { naam: "Luchthavengerelateerde Bedrijven", icon: Plane, desc: "Snelle interventie voor logistieke bedrijven, cargo-opslag en kantoren in de Luchthavenzone — 24/7 zonder onderbreking." },
];

export default function BelgianZaventemPage() {
  const localBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "SOSPro.be — Hoofdkantoor Zaventem | Spoed Loodgieter & Elektricien",
    "description": "SOSPro.be hoofdkantoor in Zaventem. 24/7 spoedloodgieter en spoedelektricien in Zaventem, Sterrebeek, Diegem en omgeving Brussels Airport. Binnen 30 minuten ter plaatse.",
    "url": "https://sospro.be/zaventem",
    "telephone": BE_CONFIG.contact.phone,
    "email": BE_CONFIG.contact.email,
    "openingHours": "Mo-Su 00:00-24:00",
    "priceRange": "Vanaf €89",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Zaventem",
      "addressRegion": "Vlaams-Brabant",
      "addressCountry": "BE"
    },
    "geo": { "@type": "GeoCoordinates", "latitude": 50.8833, "longitude": 4.4667 },
    "areaServed": [
      { "@type": "City", "name": "Zaventem" },
      { "@type": "City", "name": "Sterrebeek" },
      { "@type": "City", "name": "Diegem" },
      { "@type": "City", "name": "Sint-Stevens-Woluwe" },
      { "@type": "City", "name": "Nossegem" },
      { "@type": "City", "name": "Melsbroek" },
      { "@type": "City", "name": "Kraainem" },
      { "@type": "City", "name": "Machelen" }
    ],
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "428",
      "bestRating": "5"
    }
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      { "@type": "Question", "name": "Waar is het hoofdkantoor van SOSPro.be?", "acceptedAnswer": { "@type": "Answer", "text": "Ons hoofdkantoor is gevestigd in Zaventem, vlakbij Brussels Airport. Hierdoor zijn wij razendsnel in Zaventem zelf, Sterrebeek, Diegem en de hele luchthavenregio." } },
      { "@type": "Question", "name": "Hoe snel komt een spoedloodgieter of elektricien in Zaventem?", "acceptedAnswer": { "@type": "Answer", "text": "Omdat ons hoofdkantoor in Zaventem zelf gevestigd is, zijn wij hier sneller dan waar dan ook in België: gemiddeld binnen 30 minuten in Zaventem, Sterrebeek en Diegem." } },
      { "@type": "Question", "name": "Werkt SOSPro.be ook voor bedrijven rond Brussels Airport?", "acceptedAnswer": { "@type": "Answer", "text": "Ja. Wij zijn gespecialiseerd in spoedinterventies voor kantoorgebouwen, logistieke bedrijven en cargo-opslag in de volledige Luchthavenzone, 24/7, ook buiten kantooruren." } },
      { "@type": "Question", "name": "Helpen jullie ook met domotica en zonnepanelen in Sterrebeek?", "acceptedAnswer": { "@type": "Answer", "text": "Ja, onze erkende elektriciens hebben ervaring met domotica, zonnepanelen en laadpalen — veel gevraagd in de villawijken van Sterrebeek en omgeving Evergempark." } },
      { "@type": "Question", "name": "Wat kost een spoedloodgieter in Zaventem?", "acceptedAnswer": { "@type": "Answer", "text": "Vanaf €89 overdag, €119 in het weekend, €139 's nachts. Omdat ons hoofdkantoor in Zaventem zelf staat, rekenen wij hier nooit voorrijkosten." } }
    ]
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://sospro.be" },
      { "@type": "ListItem", "position": 2, "name": "Zaventem — Hoofdkantoor", "item": "https://sospro.be/zaventem" }
    ]
  };

  return (
    <>
      <Helmet>
        <title>Spoed Loodgieter & Elektricien Zaventem | Hoofdkantoor 24/7 | SOSPro.be</title>
        <meta name="description" content="SOSPro.be hoofdkantoor in Zaventem. ✓ 24/7 spoedloodgieter & elektricien ✓ Binnen 30 min in Zaventem, Sterrebeek, Diegem ✓ Specialist luchthavenzone & bedrijven ✓ Vaste prijs. Bel: 03 808 47 47" />
        <meta name="keywords" content="loodgieter Zaventem,elektricien Zaventem,spoed Zaventem,loodgieter Sterrebeek,elektricien Sterrebeek,loodgieter Diegem,spoed Brussels Airport,domotica Sterrebeek,elektricien luchthaven" />
        <link rel="canonical" href="https://sospro.be/zaventem" />
        <meta property="og:title" content="SOSPro.be Zaventem — Hoofdkantoor 24/7 Spoed Loodgieter & Elektricien" />
        <meta property="og:description" content="Ons hoofdkantoor staat in Zaventem. Binnen 30 minuten ter plaatse in Zaventem, Sterrebeek, Diegem en de luchthavenregio." />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">{JSON.stringify(localBusinessSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(breadcrumbSchema)}</script>
      </Helmet>

      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <Link to={beRoute("/")} className="flex items-center gap-2">
              <div className="w-9 h-9 bg-[#FF4500] rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-lg">SOSPro<span className="text-[#FF4500]">.be</span></span>
            </Link>
            <a href={`tel:${BE_CONFIG.contact.phone}`} className="flex items-center gap-2 bg-[#FF4500] text-white px-4 py-2.5 rounded-full font-bold hover:bg-[#CC3700]">
              <Phone className="w-4 h-4" /> {BE_CONFIG.contact.phoneDisplay}
            </a>
          </div>
        </header>

        {/* Breadcrumb */}
        <nav className="bg-slate-50 border-b text-sm">
          <div className="max-w-7xl mx-auto px-4 py-2 flex items-center gap-2 text-slate-500">
            <Link to={beRoute("/")} className="hover:text-[#FF4500]">Home</Link>
            <span>/</span>
            <span className="text-slate-900 font-medium">Zaventem — Hoofdkantoor</span>
          </div>
        </nav>

        {/* HERO — HQ badge prominent */}
        <section className="bg-slate-900 text-white py-12 md:py-16 relative overflow-hidden">
          <div className="absolute top-4 right-4 hidden md:block opacity-10">
            <Plane className="w-48 h-48" />
          </div>
          <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center relative">
            <div>
              <div className="inline-flex items-center gap-2 bg-[#FF4500] px-4 py-1.5 rounded-full text-sm font-bold mb-4">
                <Building2 className="w-4 h-4" /> Ons Hoofdkantoor — Zaventem
              </div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-black leading-tight mb-4">
                Spoed Loodgieter & Elektricien<br />
                <span className="text-[#FF4500]">Zaventem</span> — Binnen 30 Min<br />
                <span className="text-lg font-semibold text-slate-300">Sterrebeek · Diegem · Brussels Airport</span>
              </h1>
              <p className="text-slate-300 text-lg mb-6">
                Ons hoofdkantoor staat midden in Zaventem — daarom zijn wij <strong className="text-white">sneller dan elke concurrent</strong> in Zaventem, Sterrebeek, Diegem en de hele luchthavenregio.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 mb-5">
                <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-[#FF4500] text-white px-6 py-4 rounded-full font-black text-xl hover:bg-[#CC3700]">
                  <Phone className="w-6 h-6" /> {BE_CONFIG.contact.phoneDisplay}
                </a>
                <Link to={beRoute("/boek?city=zaventem&emergency=true")} className="inline-flex items-center justify-center gap-2 bg-white text-slate-900 px-6 py-4 rounded-full font-bold hover:bg-slate-100">
                  Online Boeken <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
              <div className="flex flex-wrap gap-4 text-sm text-slate-300">
                <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" />Binnen 30 min (HQ-voordeel)</span>
                <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" />Geen voorrijkosten</span>
                <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" />Zakelijk & particulier</span>
              </div>
            </div>
            <div className="hidden md:grid grid-cols-3 gap-3">
              {[
                { val: "30'", label: "Reactietijd (HQ)" },
                { val: "24/7", label: "Beschikbaar" },
                { val: "€89", label: "Vanaf (dag)" },
                { val: "4.9⭐", label: "428 reviews" },
                { val: "8", label: "Deelgemeenten" },
                { val: "HQ", label: "Hoofdkantoor" }
              ].map((s, i) => (
                <div key={i} className="bg-white/10 rounded-xl p-4 text-center">
                  <p className="text-2xl font-black">{s.val}</p>
                  <p className="text-slate-400 text-xs mt-1">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* URGENCY STRIP */}
        <div className="bg-[#FF4500] text-white py-2.5 text-center text-sm font-bold">
          ⚡ HQ-voordeel: in Zaventem zijn wij gemiddeld binnen 30 minuten ter plaatse — sneller dan in de rest van België. Bel <a href={`tel:${BE_CONFIG.contact.phone}`} className="underline">{BE_CONFIG.contact.phoneDisplay}</a>
        </div>

        {/* ZAKELIJKE SECTOREN — unieke Zaventem differentiator */}
        <section className="py-10 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Gespecialiseerd in de Zaventemse markt</h2>
            <p className="text-slate-600 text-sm mb-6">Van luchthavenbedrijven tot villa's in Sterrebeek — wij kennen de regio als geen ander</p>
            <div className="grid sm:grid-cols-3 gap-4">
              {ZAKELIJKE_SECTOREN.map((sector, i) => (
                <div key={i} className="bg-white border border-slate-200 rounded-xl p-5">
                  <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center mb-3">
                    <sector.icon className="w-6 h-6 text-[#FF4500]" />
                  </div>
                  <h3 className="font-bold text-slate-900 mb-2">{sector.naam}</h3>
                  <p className="text-sm text-slate-600 leading-relaxed">{sector.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* DIENSTEN */}
        <section className="py-10 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Onze diensten in Zaventem</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <Link to={beRoute("/spoed-elektricien/zaventem")} className="flex items-center justify-between bg-white border-2 border-slate-200 hover:border-[#FF4500] p-5 rounded-xl transition-all group">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                    <Zap className="w-6 h-6 text-[#FF4500]" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">Spoed Elektricien Zaventem</p>
                    <p className="text-xs text-slate-500">Stroomstoring, kortsluiting, domotica</p>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-300 group-hover:text-[#FF4500]" />
              </Link>
              <Link to={beRoute("/spoed-loodgieter/zaventem")} className="flex items-center justify-between bg-white border-2 border-slate-200 hover:border-[#FF4500] p-5 rounded-xl transition-all group">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                    <Droplet className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">Spoed Loodgieter Zaventem</p>
                    <p className="text-xs text-slate-500">Waterlek, verstopping, boiler</p>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-slate-300 group-hover:text-[#FF4500]" />
              </Link>
            </div>
          </div>
        </section>

        {/* WIJKEN ROND ZAVENTEM */}
        <section className="py-10 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Onze regio — vertrekkend vanuit ons HQ in Zaventem</h2>
            <p className="text-slate-600 text-sm mb-6">Hoe dichter bij ons hoofdkantoor, hoe sneller wij ter plaatse zijn</p>
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-3">
              {ZAVENTEM_WIJKEN.map((wijk, i) => (
                <div key={i} className={`border rounded-xl p-4 ${wijk.hq ? "border-2 border-[#FF4500] bg-orange-50" : "border-slate-200 bg-white"}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="w-4 h-4 text-[#FF4500]" />
                    <h3 className="font-bold text-slate-900 text-sm">{wijk.name}</h3>
                  </div>
                  <p className="text-xs text-slate-500 mb-3">{wijk.note}</p>
                  <div className="flex gap-2">
                    <Link to={beRoute(`/spoed-loodgieter/${wijk.slug}`)} className="flex-1 text-center py-1.5 bg-blue-50 text-blue-700 rounded-md text-xs font-medium hover:bg-blue-100">
                      Loodgieter
                    </Link>
                    <Link to={beRoute(`/spoed-elektricien/${wijk.slug}`)} className="flex-1 text-center py-1.5 bg-yellow-50 text-yellow-700 rounded-md text-xs font-medium hover:bg-yellow-100">
                      Elektricien
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* WAAROM SOSPRO ZAVENTEM */}
        <section className="py-10 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Waarom SOSPro.be de beste keuze is in Zaventem</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {[
                { title: "Hoofdkantoor = snelste reactietijd", desc: "Andere bedrijven moeten van ver komen. Wij vertrekken vanuit Zaventem zelf — gemiddeld binnen 30 minuten." },
                { title: "Expert in luchthavenzone-bedrijven", desc: "Kantoorgebouwen langs de Leuvensesteenweg, cargo-opslag, logistiek — wij kennen de specifieke noden van bedrijven rond Brussels Airport." },
                { title: "Specialist in Sterrebeek villa's", desc: "Domotica, zonnepanelen, laadpalen — onze elektriciens zijn vertrouwd met de hoogwaardige installaties in Sterrebeek en omgeving Evergempark." },
                { title: "Loodgieter + Elektricien — één HQ", desc: "Twee diensten, één telefoonnummer, één hoofdkantoor. Geen doorverwijzing naar derden zoals bij vergelijkingsplatformen." },
                { title: "Erkend & verzekerd", desc: "AREI-conform voor elektriciteit, KBO-ingeschreven loodgieters, volledig verzekerd voor particuliere en zakelijke klanten." },
                { title: "Geen voorrijkosten in eigen regio", desc: "Omdat ons kantoor in Zaventem staat, rekenen wij hier nooit voorrijkosten — in tegenstelling tot bedrijven die van ver moeten komen." }
              ].map((item, i) => (
                <div key={i} className="flex gap-3 p-4 border border-slate-100 rounded-xl">
                  <CheckCircle className="w-5 h-5 text-[#FF4500] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-slate-900 text-sm">{item.title}</p>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-10 bg-slate-50">
          <div className="max-w-3xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Veelgestelde vragen — Zaventem</h2>
            <div className="space-y-4">
              {[
                { q: "Waar is het hoofdkantoor van SOSPro.be?", a: "Ons hoofdkantoor is gevestigd in Zaventem, vlakbij Brussels Airport. Hierdoor zijn wij razendsnel in Zaventem zelf, Sterrebeek, Diegem en de hele luchthavenregio." },
                { q: "Hoe snel komt een spoedloodgieter of elektricien in Zaventem?", a: "Omdat ons hoofdkantoor in Zaventem zelf gevestigd is, zijn wij hier sneller dan waar dan ook in België: gemiddeld binnen 30 minuten in Zaventem, Sterrebeek en Diegem." },
                { q: "Werkt SOSPro.be ook voor bedrijven rond Brussels Airport?", a: "Ja. Wij zijn gespecialiseerd in spoedinterventies voor kantoorgebouwen, logistieke bedrijven en cargo-opslag in de volledige Luchthavenzone, 24/7, ook buiten kantooruren." },
                { q: "Helpen jullie ook met domotica en zonnepanelen in Sterrebeek?", a: "Ja, onze erkende elektriciens hebben ervaring met domotica, zonnepanelen en laadpalen — veel gevraagd in de villawijken van Sterrebeek en omgeving Evergempark." },
                { q: "Wat kost een spoedloodgieter in Zaventem?", a: "Vanaf €89 overdag, €119 in het weekend, €139 's nachts. Omdat ons hoofdkantoor in Zaventem zelf staat, rekenen wij hier nooit voorrijkosten." }
              ].map((item, i) => (
                <div key={i} className="bg-white border border-slate-200 rounded-xl p-5">
                  <h3 className="font-semibold text-slate-900 mb-2 text-sm">{item.q}</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">{item.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA FINAL */}
        <section className="py-14 bg-[#FF4500]">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-black text-white mb-2">Hulp nodig in Zaventem?</h2>
            <p className="text-white/90 mb-2">Ons hoofdkantoor staat hier — wij zijn altijd het snelst</p>
            <p className="text-white/70 text-sm mb-8">Zaventem · Sterrebeek · Diegem · Sint-Stevens-Woluwe · Nossegem · Melsbroek</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-white text-[#FF4500] px-8 py-4 rounded-full font-black text-xl hover:bg-slate-100">
                <Phone className="w-6 h-6" /> {BE_CONFIG.contact.phoneDisplay}
              </a>
              <Link to={beRoute("/boek?city=zaventem&emergency=true")} className="inline-flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-800">
                Online Boeken <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </section>

        <footer className="bg-slate-900 text-slate-400 py-6">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
            <Link to={beRoute("/")} className="text-white font-bold">SOSPro<span className="text-[#FF4500]">.be</span></Link>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to={beRoute("/spoed-loodgieter/zaventem")} className="hover:text-white">Loodgieter Zaventem</Link>
              <Link to={beRoute("/spoed-elektricien/zaventem")} className="hover:text-white">Elektricien Zaventem</Link>
              <Link to={beRoute("/prijzen")} className="hover:text-white">Prijzen</Link>
              <Link to={beRoute("/over-ons")} className="hover:text-white">Over ons</Link>
            </div>
            <p>© 2026 SOSPro.be — Hoofdkantoor Zaventem</p>
          </div>
        </footer>
      </div>
    </>
  );
}
