import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { Helmet } from "react-helmet-async";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Zap, Droplets, Key, Phone, Clock, Shield, Star, 
  CheckCircle, Menu, X, ArrowRight, Settings, MapPin
} from "lucide-react";
import { BE_CONFIG, BELGIAN_CITIES, BELGIAN_SERVICES, beRoute } from "@/config/belgiumConfig";
import CallButton from "@/components/common/CallButton";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const iconMap = {
  Zap: Zap,
  Droplets: Droplets,
  Key: Key
};

const SERVICE_COLORS = {
  loodgieter: "from-blue-500 to-blue-600",
  slotenmaker: "from-amber-500 to-amber-600",
  elektricien: "from-yellow-400 to-yellow-500"
};

const SERVICE_ICONS = {
  loodgieter: Droplets,
  slotenmaker: Key,
  elektricien: Zap
};

export default function BelgianLandingPage() {
  const navigate = useNavigate();
  const [services, setServices] = useState([]);
  const [stats, setStats] = useState({ total_bookings: 0, total_vakmannen: 0, total_reviews: 0, avg_rating: 4.8 });
  const [reviews, setReviews] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [lang, setLang] = useState(() => localStorage.getItem('sospro_lang') || 'nl');

  useEffect(() => {
    localStorage.setItem('sospro_lang', lang);
  }, [lang]);
  const [isEmergency, setIsEmergency] = useState(false);
  const [user, setUser] = useState(null);

  const checkAuth = () => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    if (token && userData) {
      try {
        setUser(JSON.parse(userData));
      } catch (e) {
        console.error("Error parsing user data:", e);
      }
    }
  };

  const fetchServices = async () => {
    try {
      const response = await axios.get(`${API}/services`);
      setServices(response.data);
    } catch (error) {
      console.error("Error fetching services:", error);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await axios.get(`${API}/stats/public`);
      setStats(response.data);
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  const fetchReviews = async () => {
    try {
      const response = await axios.get(`${API}/reviews/latest`);
      setReviews(response.data);
    } catch (error) {
      console.error("Error fetching reviews:", error);
    }
  };

  useEffect(() => {
    fetchServices();
    fetchStats();
    fetchReviews();
    checkAuth();
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    const query = searchQuery.toLowerCase().trim();
    const emergencyParam = isEmergency ? '?emergency=true' : '';
    
    if (!query) {
      navigate(beRoute(`/boek${emergencyParam}`));
      return;
    }
    
    if (query.includes("elektr") || query.includes("stroom") || query.includes("lamp") || query.includes("schakelaar") || query.includes("stopcontact") || query.includes("kortsluiting") || query.includes("zekering") || query.includes("differentieel")) {
      navigate(beRoute(`/boek?service=elektricien${isEmergency ? '&emergency=true' : ''}`));
    } else if (query.includes("lood") || query.includes("lek") || query.includes("kraan") || query.includes("water") || query.includes("afvoer") || query.includes("toilet") || query.includes("wc") || query.includes("verstop") || query.includes("riool") || query.includes("cv") || query.includes("verwarming")) {
      navigate(beRoute(`/boek?service=loodgieter${isEmergency ? '&emergency=true' : ''}`));
    } else if (query.includes("slot") || query.includes("deur") || query.includes("buiten") || query.includes("sleutel") || query.includes("inbraak") || query.includes("cilinder")) {
      navigate(beRoute(`/boek?service=slotenmaker${isEmergency ? '&emergency=true' : ''}`));
    } else {
      navigate(beRoute(`/boek${emergencyParam}`));
    }
  };

  const handleSuggestionClick = (term) => {
    setSearchQuery(term);
    const query = term.toLowerCase();
    const emergencyParam = isEmergency ? '&emergency=true' : '';
    
    if (query.includes("stroom") || query.includes("kortsluiting") || query.includes("differentieel")) {
      navigate(beRoute(`/boek?service=elektricien${emergencyParam}`));
    } else if (query.includes("lek") || query.includes("wc") || query.includes("verstop") || query.includes("riool")) {
      navigate(beRoute(`/boek?service=loodgieter${emergencyParam}`));
    } else if (query.includes("buiten") || query.includes("slot")) {
      navigate(beRoute(`/boek?service=slotenmaker${emergencyParam}`));
    } else {
      navigate(beRoute("/boek"));
    }
  };

  const mainCities = BELGIAN_CITIES.filter(c => 
    ["antwerpen", "brussel", "gent", "brugge", "leuven", "hasselt"].includes(c.slug)
  );

  return (
    <>
      <Helmet>
        <title>SOSPro.be — 24/7 Spoed Elektricien & Loodgieter in België | Hoofdkantoor Zaventem</title>
        <meta name="description" content="Spoedelektricien of spoedloodgieter nodig in België? ✓ 24/7 beschikbaar ✓ Binnen 45 min ter plaatse ✓ Hoofdkantoor Zaventem ✓ Erkend & verzekerd ✓ Geen voorrijkosten. Bel nu: 03 808 47 47" />
        <meta name="keywords" content="spoed elektricien België,spoed loodgieter België,loodgieter Zaventem,elektricien Zaventem,24/7 elektricien,24/7 loodgieter,stroomstoring,kortsluiting,lekkage,waterlek,verstopping,spoedservice" />
        <link rel="canonical" href="https://sospro.be/" />
        <meta property="og:title" content="SOSPro.be — 24/7 Spoed Elektricien & Loodgieter België" />
        <meta property="og:description" content="Spoedelektricien of spoedloodgieter? Binnen 45 min ter plaatse in heel België. Hoofdkantoor Zaventem. Bel 03 808 47 47." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://sospro.be/" />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">{JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "SOSPro.be",
          "url": "https://sospro.be",
          "logo": "https://sospro.be/logo.png",
          "address": {
            "@type": "PostalAddress",
            "addressLocality": "Zaventem",
            "addressRegion": "Vlaams-Brabant",
            "addressCountry": "BE"
          },
          "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+3238084747",
            "contactType": "emergency",
            "availableLanguage": ["nl","fr"],
            "areaServed": "BE",
            "hoursAvailable": "Mo-Su 00:00-24:00"
          },
          "areaServed": { "@type": "Country", "name": "Belgium" },
          "sameAs": [
            "https://www.facebook.com/sospro.be",
            "https://www.instagram.com/sospro.be",
            "https://www.linkedin.com/company/sospro-be"
          ]
        })}</script>
        <script type="application/ld+json">{JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          "name": "SOSPro.be — Hoofdkantoor",
          "image": "https://sospro.be/logo.png",
          "telephone": "+3238084747",
          "priceRange": "Vanaf €89",
          "address": {
            "@type": "PostalAddress",
            "addressLocality": "Zaventem",
            "addressRegion": "Vlaams-Brabant",
            "postalCode": "1930",
            "addressCountry": "BE"
          },
          "geo": { "@type": "GeoCoordinates", "latitude": 50.8833, "longitude": 4.4667 },
          "openingHoursSpecification": {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
            "opens": "00:00",
            "closes": "23:59"
          }
        })}</script>
      </Helmet>

      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Link to={beRoute("/")} className="flex items-center gap-2">
                <div className="w-10 h-10 bg-[#FF4500] rounded-md flex items-center justify-center">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <span className="font-bold text-xl text-slate-900">SOSPro<span className="text-[#FF4500]">.be</span></span>
              </Link>

              {/* Desktop Nav */}
              <nav className="hidden md:flex items-center gap-8">
                <Link to={beRoute("/dienst/elektricien")} className="text-slate-600 hover:text-slate-900 font-medium">Elektricien</Link>
                <Link to={beRoute("/dienst/loodgieter")} className="text-slate-600 hover:text-slate-900 font-medium">Loodgieter</Link>
                <Link to={beRoute("/over-ons")} className="text-slate-600 hover:text-slate-900 font-medium">Over Ons</Link>
              </nav>

              <div className="hidden md:flex items-center gap-4">
                {user?.role === 'admin' && (
                  <Link to="/admin" className="flex items-center gap-1 text-[#FF4500] hover:text-[#CC3700] font-medium">
                    <Settings className="w-4 h-4" />
                    Beheer
                  </Link>
                )}
                <Link to={beRoute("/vakman/register")} className="text-slate-600 hover:text-slate-900 font-medium">Word Vakman</Link>
                {user ? (
                  <Link to={user.role === 'vakman' ? '/vakman/dashboard' : '/dashboard'}>
                    <Button variant="outline">Dashboard</Button>
                  </Link>
                ) : (
                  <Link to="/login">
                    <Button variant="outline">Inloggen</Button>
                  </Link>
                )}
                <a href={`tel:${BE_CONFIG.contact.phone}`} className="flex items-center gap-2 bg-[#FF4500] text-white px-4 py-2 rounded-md font-medium hover:bg-[#CC3700] transition-colors">
                  <Phone className="w-4 h-4" />
                  <span>{BE_CONFIG.contact.phoneDisplay}</span>
                </a>
                
                {/* Taal Switcher */}
                <div className="flex items-center border-l pl-4 ml-2 gap-1">
                  <button
                    onClick={() => setLang('nl')}
                    className={`text-sm font-medium px-2 py-1 rounded ${lang === 'nl' ? 'text-[#FF4500]' : 'text-slate-400 hover:text-slate-600'}`}
                  >
                    NL
                  </button>
                  <span className="text-slate-300">|</span>
                  <button
                    onClick={() => setLang('fr')}
                    className={`text-sm font-medium px-2 py-1 rounded ${lang === 'fr' ? 'text-[#FF4500]' : 'text-slate-400 hover:text-slate-600'}`}
                  >
                    FR
                  </button>
                </div>
              </div>

              {/* Mobile Menu Button */}
              <button 
                className="md:hidden p-2"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden bg-white border-t border-slate-200 py-4">
              <nav className="flex flex-col gap-2 px-4">
                <Link to={beRoute("/dienst/elektricien")} className="py-2 text-slate-600 hover:text-slate-900">Elektricien</Link>
                <Link to={beRoute("/dienst/loodgieter")} className="py-2 text-slate-600 hover:text-slate-900">Loodgieter</Link>
                <Link to={beRoute("/over-ons")} className="py-2 text-slate-600 hover:text-slate-900">Over Ons</Link>
                <Link to={beRoute("/vakman/register")} className="py-2 text-slate-600 hover:text-slate-900">Word Vakman</Link>
                {user?.role === 'admin' && (
                  <Link to="/admin" className="py-2 text-[#FF4500] hover:text-[#CC3700] font-medium flex items-center gap-2">
                    <Settings className="w-4 h-4" />
                    Admin Beheer
                  </Link>
                )}
                {user ? (
                  <Link to={user.role === 'vakman' ? '/vakman/dashboard' : '/dashboard'} className="py-2 text-slate-600 hover:text-slate-900">Dashboard</Link>
                ) : (
                  <Link to="/login" className="py-2 text-slate-600 hover:text-slate-900">Inloggen</Link>
                )}
                <a href={`tel:${BE_CONFIG.contact.phone}`} className="flex items-center gap-2 bg-[#FF4500] text-white px-4 py-3 rounded-md font-medium hover:bg-[#CC3700] transition-colors mt-2">
                  <Phone className="w-4 h-4" />
                  <span>{BE_CONFIG.contact.phoneDisplay}</span>
                </a>
                {/* Taal Switcher Mobile */}
                <div className="flex items-center gap-2 mt-4 pt-4 border-t">
                  <button onClick={() => setLang('nl')} className={`px-3 py-1 rounded text-sm ${lang === 'nl' ? 'bg-[#FF4500] text-white' : 'bg-slate-100 text-slate-700'}`}>Nederlands</button>
                  <button onClick={() => setLang('fr')} className={`px-3 py-1 rounded text-sm ${lang === 'fr' ? 'bg-[#FF4500] text-white' : 'bg-slate-100 text-slate-700'}`}>Français</button>
                </div>
              </nav>
            </div>
          )}
        </header>

        {/* Hero Section */}
        <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <Badge className="bg-[#FF4500] text-white mb-6 px-4 py-1.5 text-sm font-medium">
                  🇧🇪 24/7 Spoed Beschikbaar in België
                </Badge>
                <h1 className="font-black text-4xl sm:text-5xl lg:text-6xl text-slate-900 mb-4 leading-tight">
                  24/7 Spoed<span className="text-[#FF4500]">elektricien & Spoedloodgieter</span>
                </h1>
                <p className="text-xl text-slate-700 font-medium mb-2">
                  Heel België — Direct hulp nodig?
                </p>
                <p className="text-lg text-slate-600 mb-8 max-w-lg">
                  Binnen 45 minuten ter plaatse. Direct hulp bij stroomstoring, kortsluiting, waterlek of verstopping. Vaste prijs, gecertificeerde vakmannen.
                </p>

                {/* Search Box */}
                <form onSubmit={handleSearch} className="mb-6">
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="flex-1 relative">
                      <Input
                        type="text"
                        placeholder="Wat is je probleem? (bijv. lekkage, kortsluiting)"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="h-14 pl-4 pr-4 text-base bg-white border-slate-200"
                        data-testid="search-input"
                      />
                    </div>
                    <Button 
                      type="submit" 
                      className="h-14 px-8 bg-[#FF4500] hover:bg-[#CC3700] text-white font-semibold text-base"
                      data-testid="search-btn"
                    >
                      Zoek Vakman
                    </Button>
                  </div>
                  
                  {/* Emergency Toggle */}
                  <label className="flex items-center gap-3 mt-4 cursor-pointer">
                    <div 
                      className={`relative w-12 h-6 rounded-full transition-colors ${isEmergency ? 'bg-[#FF4500]' : 'bg-slate-200'}`}
                      onClick={() => setIsEmergency(!isEmergency)}
                    >
                      <div className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${isEmergency ? 'translate-x-6' : ''}`} />
                    </div>
                    <span className="text-slate-700 font-medium">Spoed - Direct hulp nodig</span>
                  </label>
                </form>

                {/* Popular Search Suggestions */}
                <div className="mb-8">
                  <p className="text-sm text-slate-500 mb-2">Populaire zoekopdrachten:</p>
                  <div className="flex flex-wrap gap-2">
                    {['Lekkage', 'WC verstopt', 'Stroomstoring', 'Riool verstopt', 'Kortsluiting', 'Differentieel', 'Boiler defect', 'Zekering gesprongen'].map((term) => (
                      <button
                        key={term}
                        type="button"
                        onClick={() => handleSuggestionClick(term)}
                        className="px-3 py-1.5 bg-white border border-slate-200 rounded-full text-sm text-slate-600 hover:border-[#FF4500] hover:text-[#FF4500] transition-colors"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Trust Badges */}
                <div className="flex flex-wrap gap-6">
                  <div className="flex items-center gap-2 text-slate-600">
                    <Clock className="w-5 h-5 text-[#FF4500]" />
                    <span className="text-sm font-medium">Snel geholpen</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Star className="w-5 h-5 text-[#FF4500]" />
                    <span className="text-sm font-medium">{stats.avg_rating || 4.8}/5 beoordeling</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Shield className="w-5 h-5 text-[#FF4500]" />
                    <span className="text-sm font-medium">Tevredenheidsgarantie</span>
                  </div>
                </div>
              </div>

              {/* Hero Image */}
              <div className="relative hidden lg:block">
                <div className="relative">
                  <div
                    role="img"
                    aria-label="SOSPro - Spoedelektricien & Spoedloodgieter - Binnen 45 minuten ter plaatse"
                    className="rounded-2xl shadow-2xl w-full aspect-[4/3] bg-gradient-to-br from-slate-800 via-slate-900 to-black flex items-center justify-center"
                  >
                    <div className="text-center text-white/80 px-8">
                      <div className="text-6xl mb-4">⚡🔧</div>
                      <p className="text-lg font-semibold">Vervang met eigen vakman-foto</p>
                      <p className="text-sm text-white/50 mt-1">(1200x900px aanbevolen)</p>
                    </div>
                  </div>
                  {/* Floating Badge */}
                  <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">150+ Vakmannen</p>
                        <p className="text-sm text-slate-500">Elektriciens & loodgieters in België</p>
                      </div>
                    </div>
                  </div>
                  {/* Location Badge */}
                  <div className="absolute -top-4 -right-4 bg-[#FF4500] text-white rounded-xl shadow-lg px-4 py-2">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span className="font-medium text-sm">Heel België</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                Onze spoeddiensten in België
              </h2>
              <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                Erkende elektriciens en loodgieters, 24/7 inzetbaar in heel België
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto">
              {BELGIAN_SERVICES.filter(s => s.slug !== "slotenmaker").map(service => {
                const Icon = SERVICE_ICONS[service.slug];
                return (
                  <Link
                    key={service.slug}
                    to={beRoute(`/dienst/${service.slug}`)}
                    className="group p-8 rounded-2xl bg-white border border-slate-200 hover:border-[#FF4500] hover:shadow-lg transition-all duration-300"
                  >
                    <div className="w-16 h-16 bg-orange-50 text-[#FF4500] rounded-xl flex items-center justify-center mb-6">
                      <Icon className="w-8 h-8" />
                    </div>
                    <h3 className="text-2xl font-bold mb-2 text-slate-900">{service.name}</h3>
                    <p className="text-slate-600 mb-4">{service.description}</p>
                    <div className="flex items-center gap-2 text-[#FF4500] font-medium group-hover:gap-4 transition-all">
                      <span>Meer info</span>
                      <ArrowRight className="w-5 h-5" />
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>

        {/* Regions Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="bg-[#FF4500]/10 text-[#FF4500] mb-4">
                <MapPin className="w-4 h-4 mr-1" />
                Werkgebied
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                Actief in heel België
              </h2>
              <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                Ons netwerk van spoedelektriciens en -loodgieters bedekt alle Belgische provincies
              </p>
            </div>

            {/* Zaventem HQ Spotlight */}
            <div className="mb-10 p-6 bg-white border-t-4 border-[#FF4500] rounded-xl shadow-sm">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <span className="inline-block bg-orange-50 text-[#FF4500] text-xs font-bold px-3 py-1 rounded-full mb-2">🏢 Ons Hoofdkantoor</span>
                  <h3 className="text-xl font-bold text-slate-900">Spoed Loodgieter & Elektricien Zaventem</h3>
                  <p className="text-slate-500 text-sm">Sterrebeek · Diegem · Brussels Airport — binnen 30 min, het snelst van heel België</p>
                </div>
                <Link to={beRoute("/zaventem")} className="bg-[#FF4500] text-white px-6 py-2.5 rounded-full font-bold text-sm whitespace-nowrap hover:bg-[#CC3700]">
                  Bekijk Zaventem →
                </Link>
              </div>
            </div>

            {/* Province Grid - klikbaar naar dienst */}
            <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-8">
              {["Antwerpen", "Brussels Hoofdstedelijk Gewest", "Oost-Vlaanderen", "West-Vlaanderen", "Vlaams-Brabant", "Limburg"].map(province => {
                const provinceCities = BELGIAN_CITIES.filter(c => c.province === province);
                const displayName = province === "Brussels Hoofdstedelijk Gewest" ? "Brussel" : province;
                const capitalCity = provinceCities.find(c => c.isCapital) || provinceCities[0];
                return (
                  <Link key={province} to={beRoute(`/spoed-elektricien/${capitalCity?.slug || provinceCities[0]?.slug}`)} className="border-2 hover:border-[#FF4500] transition-colors rounded-xl block">
                    <div className="p-4">
                      <h3 className="font-bold text-slate-900 mb-2 text-sm">{displayName}</h3>
                      <p className="text-2xl font-bold text-[#FF4500]">{provinceCities.length}</p>
                      <p className="text-xs text-slate-500">gemeenten</p>
                    </div>
                  </Link>
                );
              })}
            </div>

            {/* City Pills — beide diensten */}
            <div className="mb-4 flex gap-2 justify-center">
              <span className="text-sm font-medium text-slate-600">Ga direct naar:</span>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {BELGIAN_CITIES.slice(0, 16).map(city => (
                <div key={city.slug} className="flex gap-1">
                  <Link to={beRoute(`/spoed-elektricien/${city.slug}`)} className="px-3 py-1.5 bg-yellow-50 border border-yellow-200 hover:bg-yellow-400 hover:text-white rounded-full text-xs font-medium transition-colors">
                    ⚡ {city.name}
                  </Link>
                  <Link to={beRoute(`/spoed-loodgieter/${city.slug}`)} className="px-3 py-1.5 bg-blue-50 border border-blue-200 hover:bg-blue-500 hover:text-white rounded-full text-xs font-medium transition-colors">
                    🔧 {city.name}
                  </Link>
                </div>
              ))}
              <Link to={beRoute("/dienst/elektricien")} className="px-4 py-1.5 bg-slate-100 border border-slate-200 hover:border-[#FF4500] hover:text-[#FF4500] rounded-full text-xs font-medium transition-colors">
                + Alle steden →
              </Link>
            </div>
          </div>
        </section>

        {/* Reviews Section */}
        {reviews.length > 0 && (
          <section className="py-20 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                  Wat onze klanten zeggen
                </h2>
                <div className="flex items-center justify-center gap-2">
                  <Star className="w-6 h-6 text-yellow-400 fill-yellow-400" />
                  <span className="text-2xl font-bold text-slate-900">{stats.avg_rating || 4.8}</span>
                  <span className="text-slate-500">gemiddelde beoordeling</span>
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                {reviews.slice(0, 3).map((review, index) => (
                  <Card key={index} className="border-2 hover:border-[#FF4500] transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-1 mb-4">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-4 h-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-slate-200'}`} 
                          />
                        ))}
                      </div>
                      <p className="text-slate-600 mb-4">"{review.comment}"</p>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#FF4500] rounded-full flex items-center justify-center text-white font-bold">
                          {review.customer_name?.charAt(0) || 'K'}
                        </div>
                        <div>
                          <p className="font-medium text-slate-900">{review.customer_name || 'Klant'}</p>
                          <p className="text-sm text-slate-500">{review.service_type}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* CTA Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#FF4500]">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Direct hulp nodig in België?
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Onze vakmannen staan 24/7 klaar om u te helpen
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href={`tel:${BE_CONFIG.contact.phone}`}
                className="inline-flex items-center justify-center gap-2 bg-white text-[#FF4500] px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-100 transition-colors"
              >
                <Phone className="w-6 h-6" />
                {BE_CONFIG.contact.phoneDisplay}
              </a>
              <CallButton
                label="Gratis bellen via internet"
                className="!rounded-full !px-8 !py-4 !text-lg"
              />
              <Link 
                to={beRoute("/boek")}
                className="inline-flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-800 transition-colors"
              >
                Online Boeken
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-slate-900 text-white py-16">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid md:grid-cols-4 gap-8 mb-12">
              <div>
                <Link to={beRoute("/")} className="flex items-center gap-2 mb-4">
                  <div className="w-10 h-10 bg-[#FF4500] rounded-md flex items-center justify-center">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <span className="font-bold text-xl">SOSPro<span className="text-[#FF4500]">.be</span></span>
                </Link>
                <p className="text-slate-400 text-sm">
                  24/7 spoedelektricien & spoedloodgieter in heel België.
                </p>
              </div>
              
              <div>
                <h4 className="font-bold mb-4">Diensten</h4>
                <ul className="space-y-2 text-slate-400 text-sm">
                  <li><Link to={beRoute("/dienst/loodgieter")} className="hover:text-white">Loodgieter</Link></li>
                  <li><Link to={beRoute("/dienst/elektricien")} className="hover:text-white">Elektricien</Link></li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-bold mb-4">Spoedproblemen</h4>
                <ul className="space-y-2 text-slate-400 text-sm">
                  <li><Link to={beRoute("/lekkage-spoed")} className="hover:text-white">Lekkage Spoed</Link></li>
                  <li><Link to={beRoute("/stroomstoring-spoed")} className="hover:text-white">Stroomstoring</Link></li>
                  <li><Link to={beRoute("/toilet-verstopt-spoed")} className="hover:text-white">Toilet Verstopt</Link></li>
                  <li><Link to={beRoute("/kortsluiting-spoed")} className="hover:text-white">Kortsluiting</Link></li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-bold mb-4">Over Ons</h4>
                <ul className="space-y-2 text-slate-400 text-sm">
                  <li><Link to={beRoute("/over-ons")} className="hover:text-white">Over SOSPro.be</Link></li>
                  <li><Link to={beRoute("/prijzen")} className="hover:text-white">Prijzen</Link></li>
                  <li><Link to={beRoute("/garantie")} className="hover:text-white">Garantie</Link></li>
                  <li><Link to={beRoute("/vakman")} className="hover:text-white">Word Vakman</Link></li>
                </ul>
                
                <h4 className="font-bold mb-4 mt-6">Contact België</h4>
                <ul className="space-y-2 text-slate-400 text-sm">
                  <li className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    <a href={`tel:${BE_CONFIG.contact.phone}`} className="hover:text-white">{BE_CONFIG.contact.phoneDisplay}</a>
                  </li>
                  <li>
                    <a href={`mailto:${BE_CONFIG.contact.email}`} className="hover:text-white">{BE_CONFIG.contact.email}</a>
                  </li>
                </ul>
              </div>
            </div>
            
            {/* SEO Footer Links */}
            <div className="border-t border-slate-800 mt-8 pt-8">
              <h4 className="font-bold text-sm mb-4 text-slate-400">Spoed Loodgieter België</h4>
              <div className="flex flex-wrap gap-2 text-xs text-slate-500 mb-4">
                {BELGIAN_CITIES.slice(0, 15).map(city => (
                  <Link key={city.slug} to={beRoute(`/spoed-loodgieter/${city.slug}`)} className="hover:text-white">
                    Loodgieter {city.name}
                  </Link>
                ))}
              </div>
              
              <h4 className="font-bold text-sm mb-4 text-slate-400">Spoed Elektricien België</h4>
              <div className="flex flex-wrap gap-2 text-xs text-slate-500">
                {BELGIAN_CITIES.slice(0, 15).map(city => (
                  <Link key={city.slug} to={beRoute(`/spoed-elektricien/${city.slug}`)} className="hover:text-white">
                    Elektricien {city.name}
                  </Link>
                ))}
              </div>
            </div>
            
            <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-500 text-sm">
              <div className="flex flex-wrap justify-center gap-4 mb-4">
                <Link to={beRoute("/voorwaarden")} className="hover:text-white">Algemene Voorwaarden</Link>
                <span>|</span>
                <Link to={beRoute("/privacy")} className="hover:text-white">Privacy Policy</Link>
                <span>|</span>
                <Link to={beRoute("/cookies")} className="hover:text-white">Cookie Beleid</Link>
              </div>
              <p>© 2024 SOSPro.be - Alle rechten voorbehouden | 24/7 Vakmannen in België</p>
              <p className="mt-2">Spoedelektricien België | Spoedloodgieter België | 24/7 Vakmannen heel België</p>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}
