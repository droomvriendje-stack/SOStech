import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Phone, CheckCircle, ArrowRight, Zap, AlertTriangle, Euro } from "lucide-react";
import { BE_CONFIG, BELGIAN_SERVICES, beRoute } from "@/config/belgiumConfig";

export default function BelgianPrijzenPage() {
  const priceSchema = {
    "@context": "https://schema.org",
    "@type": "PriceSpecification",
    "name": "SOSPro.be Tarieven Spoeddiensten België",
    "description": "Transparante spoedtarieven voor elektricien en loodgieter in België. Geen voorrijkosten.",
    "url": "https://sospro.be/prijzen",
    "priceCurrency": "EUR"
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      { "@type": "Question", "name": "Zijn er voorrijkosten bij SOSPro.be?", "acceptedAnswer": { "@type": "Answer", "text": "Nee. SOSPro.be rekent geen voorrijkosten. De prijs die u hoort is de prijs die u betaalt." } },
      { "@type": "Question", "name": "Wat kost een spoedelektricien 's nachts in België?", "acceptedAnswer": { "@type": "Answer", "text": "Nachttarief voor een spoedelektricien (22u–8u) is vanaf €149. Overdag vanaf €89. Weekend/feestdag vanaf €129." } },
      { "@type": "Question", "name": "Wat kost een spoedloodgieter in het weekend?", "acceptedAnswer": { "@type": "Answer", "text": "Weekend en feestdagen: vanaf €119 voor een spoedloodgieter. Overdag (ma-vr 8u-18u) vanaf €89." } }
    ]
  };

  return (
    <>
      <Helmet>
        <title>Prijzen Spoed Elektricien & Loodgieter België 2026 | SOSPro.be</title>
        <meta name="description" content="Transparante prijzen voor spoedelektricien en spoedloodgieter in België. ✓ Geen voorrijkosten ✓ Vaste prijs ✓ Geen verrassingen. Overdag vanaf €89. Bel: 03 808 47 47" />
        <link rel="canonical" href="https://sospro.be/prijzen" />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
      </Helmet>

      <div className="min-h-screen bg-white">
        <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <Link to={beRoute("/")} className="flex items-center gap-2">
              <div className="w-9 h-9 bg-[#FF4500] rounded-xl flex items-center justify-center"><Zap className="w-5 h-5 text-white" /></div>
              <span className="font-bold text-lg">SOSPro<span className="text-[#FF4500]">.be</span></span>
            </Link>
            <a href={`tel:${BE_CONFIG.contact.phone}`} className="flex items-center gap-2 bg-[#FF4500] text-white px-4 py-2.5 rounded-full font-bold hover:bg-[#CC3700]">
              <Phone className="w-4 h-4" /> {BE_CONFIG.contact.phoneDisplay}
            </a>
          </div>
        </header>

        <nav className="bg-slate-50 border-b text-sm">
          <div className="max-w-7xl mx-auto px-4 py-2 flex gap-2 text-slate-500">
            <Link to={beRoute("/")} className="hover:text-[#FF4500]">Home</Link>
            <span>/</span><span className="text-slate-900 font-medium">Prijzen</span>
          </div>
        </nav>

        <section className="py-12 bg-slate-900 text-white">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-4xl font-black mb-3">Transparante Tarieven — Spoed Elektricien & Loodgieter België</h1>
            <p className="text-slate-300 text-lg">Geen voorrijkosten. Geen verborgen kosten. Altijd vaste prijs voor aanvang van de werken.</p>
          </div>
        </section>

        <section className="py-12">
          <div className="max-w-5xl mx-auto px-4">
            {BELGIAN_SERVICES.filter(s => s.slug !== "slotenmaker").map(service => (
              <div key={service.slug} className="mb-12">
                <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <span className="text-2xl">{service.slug === "elektricien" ? "⚡" : "🔧"}</span>
                  Spoed {service.name} — Tarieven België
                </h2>
                <div className="grid sm:grid-cols-3 gap-4 mb-4">
                  {[
                    { label: "Overdag", time: "Ma–vr 8u–18u", price: `€${service.priceFrom}`, note: "Meest voorkomend", best: false },
                    { label: "Avond & Weekend", time: "18u–22u, Za–Zo", price: `€${service.priceSpoed}`, note: "Spoedtarief", best: true },
                    { label: "Nacht & Feestdag", time: "22u–8u, feestdagen", price: `€${service.priceSpoed + 20}`, note: "Nacht spoedtarief", best: false }
                  ].map((p, i) => (
                    <div key={i} className={`p-5 rounded-xl border-2 ${p.best ? "border-[#FF4500] bg-orange-50" : "border-slate-200"}`}>
                      {p.best && <span className="inline-block mb-2 text-xs bg-[#FF4500] text-white px-2 py-0.5 rounded-full">Meest gevraagd</span>}
                      <p className="font-bold text-slate-900">{p.label}</p>
                      <p className="text-xs text-slate-500 mb-2">{p.time}</p>
                      <p className="text-3xl font-black text-slate-900">{p.price}</p>
                      <p className="text-xs text-slate-400 mt-1">per interventie</p>
                    </div>
                  ))}
                </div>
                <div className="bg-slate-50 rounded-xl p-4 text-sm text-slate-600">
                  <p className="font-medium mb-2">Wat is inbegrepen bij {service.name} interventie:</p>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {["Verplaatsing vakman (geen voorrijkosten)","Diagnose ter plaatse","Eerste uur arbeid","Rapport & advies"].map((item, i) => (
                      <span key={i} className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" /> {item}</span>
                    ))}
                  </div>
                  <p className="mt-3 text-xs text-slate-400">* Materialen worden apart gefactureerd na akkoord. Extra arbeidsuren: €{service.slug === "elektricien" ? "65" : "60"}/uur.</p>
                </div>
                <div className="mt-4">
                  <Link to={beRoute(`/dienst/${service.slug}`)} className="inline-flex items-center gap-2 text-[#FF4500] font-medium hover:underline">
                    Meer info over spoed {service.name} <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            ))}

            <div className="bg-green-50 border border-green-200 rounded-2xl p-6 mb-8">
              <h3 className="font-bold text-green-800 mb-3 flex items-center gap-2"><CheckCircle className="w-5 h-5" /> Onze prijsgaranties</h3>
              <div className="grid sm:grid-cols-2 gap-3">
                {[
                  "Geen voorrijkosten — ook 's nachts niet",
                  "Prijs altijd besproken vóór aanvang",
                  "Geen verborgen kosten op factuur",
                  "Bij twijfel: gratis telefonisch advies",
                  "Betaling achteraf (cash, bancontact, factuur)",
                  "Tevredenheidsgarantie: niet opgelost? Terugkeer gratis"
                ].map((g, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-green-700">
                    <CheckCircle className="w-4 h-4 flex-shrink-0" /> {g}
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4 mb-8">
              <h2 className="text-2xl font-bold text-slate-900">Veelgestelde vragen over prijzen</h2>
              {[
                { q: "Zijn er voorrijkosten?", a: "Nee. SOSPro.be rekent geen voorrijkosten. De prijs die u hoort is de prijs die u betaalt — ook bij nachtinterventies." },
                { q: "Moet ik vooraf betalen?", a: "Nee. U betaalt na de interventie, nadat het probleem is opgelost en u akkoord gaat met de factuur. We aanvaarden cash, Bancontact en factuur." },
                { q: "Wat als de interventie langer duurt?", a: "Extra uren worden vooraf besproken en nooit stilzwijgend aangerekend. Elektricien extra uur: €65. Loodgieter extra uur: €60." },
                { q: "Kan ik een offerte krijgen voor aanvang?", a: "Ja. U krijgt altijd een mondelinge prijsindicatie vóór de vakman begint. Grotere werken: schriftelijke offerte." }
              ].map((item, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-5">
                  <h3 className="font-semibold text-slate-900 mb-2">{item.q}</h3>
                  <p className="text-slate-600 text-sm">{item.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-12 bg-[#FF4500]">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-black text-white mb-2">Direct een spoed vakman nodig?</h2>
            <p className="text-white/90 mb-6">Bel ons — geen wachtrij, direct advies en interventie</p>
            <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-white text-[#FF4500] px-10 py-4 rounded-full font-black text-2xl hover:bg-slate-100">
              <Phone className="w-7 h-7" /> {BE_CONFIG.contact.phoneDisplay}
            </a>
          </div>
        </section>
      </div>
    </>
  );
}
