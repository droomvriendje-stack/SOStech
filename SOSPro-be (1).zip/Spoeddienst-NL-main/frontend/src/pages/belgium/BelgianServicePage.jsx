import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Zap, Droplet, Phone, Clock, Shield, Star, 
  MapPin, CheckCircle, ArrowRight, AlertTriangle,
  Euro, ThumbsUp, Wrench
} from "lucide-react";
import { BE_CONFIG, BELGIAN_CITIES, BELGIAN_SERVICES, beRoute } from "@/config/belgiumConfig";

const SERVICE_ICONS = { loodgieter: Droplet, slotenmaker: Zap, elektricien: Zap };

const SERVICE_DATA = {
  elektricien: {
    hero: "Spoed Elektricien in België — 24/7 Binnen 45 Min Ter Plaatse",
    heroSub: "Stroomstoring? Kortsluiting? Differentieel uitgeschakeld? Onze erkende elektriciens komen direct naar u toe — dag, nacht, weekend en feestdagen.",
    metaTitle: "Spoed Elektricien België | 24/7 Erkend | Binnen 45 Min | SOSPro.be",
    metaDesc: "Spoedelektricien nodig in België? ✓ 24/7 beschikbaar ✓ Binnen 45 minuten ter plaatse ✓ Erkend & gecertificeerd ✓ Vaste prijs zonder verrassingen. Bel nu: 03 808 47 47",
    priceFrom: "€89",
    priceSpoed: "€129",
    color: "from-yellow-500 to-orange-500",
    icon: "⚡",
    problems: [
      { name: "Stroomstoring", slug: "stroomstoring-spoed", urgent: true },
      { name: "Kortsluiting", slug: "kortsluiting-spoed", urgent: true },
      { name: "Differentieel uitgeschakeld", slug: "stroomstoring-spoed", urgent: true },
      { name: "Zekeringkast defect", slug: "stroomstoring-spoed", urgent: false },
      { name: "Stopcontact vonkt", slug: "kortsluiting-spoed", urgent: true },
      { name: "Verlichting defect", slug: "stroomstoring-spoed", urgent: false },
    ],
    waarom: [
      "Brandgevaar bij kortsluiting — elke minuut telt",
      "Elektriciteitsnet raakt oververhit zonder ingrijpen",
      "Koelkast & vitale toestellen vallen uit",
      "Erkend nodig voor verzekeringsdossier"
    ],
    faq: [
      { q: "Hoe snel komt een spoedelektricien in België?", a: "Onze elektriciens zijn gemiddeld binnen 45 minuten ter plaatse in heel België. In Antwerpen, Brussel en Gent vaak sneller." },
      { q: "Wat kost een spoed elektricien 's nachts?", a: "Nachttarief: vanaf €129 voor spoedinterventie. Overdag vanaf €89. Altijd vaste prijs, geen verborgen kosten." },
      { q: "Werkt SOSPro.be ook in het weekend?", a: "Ja, 7 dagen op 7, 365 dagen per jaar. Onze elektriciens werken ook op feestdagen." },
      { q: "Is uw elektricien erkend in België?", a: "Ja, al onze elektriciens zijn erkend door het AREI (Algemeen Reglement op de Elektrische Installaties) en volledig verzekerd." },
      { q: "Wat doe ik bij stroomstoring terwijl ik wacht?", a: "Schakel het grote groepje uit op de meterkast. Ontkoppel gevoelige toestellen. Bel ons: wij geven gratis telefonisch advies terwijl onze elektricien onderweg is." }
    ]
  },
  loodgieter: {
    hero: "Spoed Loodgieter in België — 24/7 Binnen 45 Min Bij Lekkage",
    heroSub: "Waterlek? Verstopt toilet? Boiler defect? Onze erkende loodgieters stoppen de schade direct — dag en nacht, ook in het weekend.",
    metaTitle: "Spoed Loodgieter België | 24/7 Lekkage & Verstopping | SOSPro.be",
    metaDesc: "Spoedloodgieter nodig in België? ✓ 24/7 beschikbaar ✓ Binnen 45 minuten ter plaatse ✓ Geen voorrijkosten ✓ Vaste prijs. Bel nu: 03 808 47 47",
    priceFrom: "€89",
    priceSpoed: "€119",
    color: "from-blue-500 to-blue-600",
    icon: "🔧",
    problems: [
      { name: "Waterleiding gebarsten", slug: "lekkage-spoed", urgent: true },
      { name: "Lekkage & waterlek", slug: "lekkage-spoed", urgent: true },
      { name: "Toilet verstopt", slug: "toilet-verstopt-spoed", urgent: true },
      { name: "Boiler / cv-ketel defect", slug: "stroomstoring-spoed", urgent: true },
      { name: "Riool verstopt", slug: "toilet-verstopt-spoed", urgent: false },
      { name: "Geen warm water", slug: "lekkage-spoed", urgent: false },
    ],
    waarom: [
      "Waterlek veroorzaakt in 1 uur €1.000+ waterschade",
      "Schimmel en vochtproblemen na 24u onbehandeld lek",
      "Appartement overstroomt buren → verzekering vereist snelle actie",
      "Verstopte riool loopt terug → vloer overstroomd"
    ],
    faq: [
      { q: "Hoe snel komt een spoedloodgieter bij mij?", a: "Gemiddeld 45 minuten na uw oproep. In drukke gebieden als Antwerpen, Gent en Brussel soms sneller." },
      { q: "Wat kost een spoedloodgieter in België?", a: "Vanaf €89 overdag, €119 voor spoedinterventies 's nachts of in het weekend. Geen voorrijkosten, altijd vaste prijs." },
      { q: "Wat doe ik bij een waterleiding die barst?", a: "Sluit de hoofdkraan af (meestal in kelder of meterkast). Bel ons direct op 03 808 47 47 — onze loodgieter is onderweg terwijl wij u telefonisch begeleiden." },
      { q: "Werkt u ook voor verstoppingen en riool?", a: "Ja, onze loodgieters ontstoppen afvoeren, toiletten en rioollijnen met professioneel hogedrukmmateriaal." },
      { q: "Zijn uw loodgieters erkend?", a: "Ja, al onze loodgieters zijn gecertificeerd, volledig verzekerd en ingeschreven bij de KBO." }
    ]
  }
};

export default function BelgianServicePage() {
  const { serviceSlug } = useParams();
  const service = BELGIAN_SERVICES.find(s => s.slug === serviceSlug);
  const data = SERVICE_DATA[serviceSlug];

  if (!service || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Dienst niet gevonden</h1>
          <Link to={beRoute("/")} className="text-[#FF4500] hover:underline">← Terug naar home</Link>
        </div>
      </div>
    );
  }

  const citiesByProvince = {};
  BELGIAN_CITIES.forEach(city => {
    if (!citiesByProvince[city.province]) citiesByProvince[city.province] = [];
    citiesByProvince[city.province].push(city);
  });

  const schemaOrg = {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": `Spoed ${service.name} België`,
    "provider": {
      "@type": "LocalBusiness",
      "name": "SOSPro.be",
      "telephone": BE_CONFIG.contact.phone,
      "url": "https://sospro.be",
      "areaServed": { "@type": "Country", "name": "Belgium" },
      "openingHours": "Mo-Su 00:00-24:00",
      "priceRange": `Vanaf ${data.priceFrom}`
    },
    "availableChannel": {
      "@type": "ServiceChannel",
      "servicePhone": BE_CONFIG.contact.phone
    }
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": data.faq.map(f => ({
      "@type": "Question",
      "name": f.q,
      "acceptedAnswer": { "@type": "Answer", "text": f.a }
    }))
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://sospro.be" },
      { "@type": "ListItem", "position": 2, "name": `Spoed ${service.name}`, "item": `https://sospro.be/dienst/${serviceSlug}` }
    ]
  };

  return (
    <>
      <Helmet>
        <title>{data.metaTitle}</title>
        <meta name="description" content={data.metaDesc} />
        <link rel="canonical" href={`https://sospro.be/dienst/${serviceSlug}`} />
        <meta property="og:title" content={data.metaTitle} />
        <meta property="og:description" content={data.metaDesc} />
        <meta property="og:url" content={`https://sospro.be/dienst/${serviceSlug}`} />
        <meta property="og:type" content="website" />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">{JSON.stringify(schemaOrg)}</script>
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(breadcrumbSchema)}</script>
      </Helmet>

      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <Link to={beRoute("/")} className="flex items-center gap-2">
              <div className="w-10 h-10 bg-[#FF4500] rounded-xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <span className="font-bold text-xl">SOSPro<span className="text-[#FF4500]">.be</span></span>
            </Link>
            <div className="flex items-center gap-3">
              <Link to={beRoute(`/dienst/${serviceSlug === 'elektricien' ? 'loodgieter' : 'elektricien'}`)} className="hidden md:block text-sm text-slate-600 hover:text-[#FF4500]">
                Ook {serviceSlug === 'elektricien' ? 'Loodgieter' : 'Elektricien'} nodig? →
              </Link>
              <a href={`tel:${BE_CONFIG.contact.phone}`} className="flex items-center gap-2 bg-[#FF4500] text-white px-4 py-2.5 rounded-full font-bold hover:bg-[#CC3700] transition-colors">
                <Phone className="w-4 h-4" />
                <span>{BE_CONFIG.contact.phoneDisplay}</span>
              </a>
            </div>
          </div>
        </header>

        {/* Breadcrumb */}
        <nav className="bg-slate-50 border-b" aria-label="Breadcrumb">
          <div className="max-w-7xl mx-auto px-4 py-2 text-sm text-slate-500">
            <Link to={beRoute("/")} className="hover:text-[#FF4500]">Home</Link>
            <span className="mx-2">/</span>
            <span className="text-slate-900 font-medium">Spoed {service.name}</span>
          </div>
        </nav>

        {/* HERO */}
        <section className="bg-slate-900 text-white py-14 md:py-20">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-10 items-center">
              <div>
                <div className="inline-flex items-center gap-2 bg-[#FF4500] text-white text-sm font-medium px-4 py-1.5 rounded-full mb-5">
                  <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                  24/7 Beschikbaar — ook nu
                </div>
                <h1 className="text-3xl md:text-5xl font-black leading-tight mb-4">{data.hero}</h1>
                <p className="text-lg text-slate-300 mb-6">{data.heroSub}</p>
                <div className="flex flex-col sm:flex-row gap-3 mb-6">
                  <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-[#FF4500] text-white px-6 py-3.5 rounded-full font-bold text-lg hover:bg-[#CC3700] transition-colors">
                    <Phone className="w-5 h-5" /> Bel Nu: {BE_CONFIG.contact.phoneDisplay}
                  </a>
                  <Link to={beRoute(`/boek?service=${serviceSlug}`)} className="inline-flex items-center justify-center gap-2 bg-white text-slate-900 px-6 py-3.5 rounded-full font-bold hover:bg-slate-100 transition-colors">
                    Online Boeken <ArrowRight className="w-5 h-5" />
                  </Link>
                </div>
                <div className="flex flex-wrap gap-4 text-sm text-slate-300">
                  <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" /> Binnen 45 minuten</span>
                  <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" /> Geen voorrijkosten</span>
                  <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" /> Vaste prijs</span>
                  <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" /> Erkend & verzekerd</span>
                </div>
              </div>
              <div className="hidden md:grid grid-cols-2 gap-4">
                <div className="bg-white/10 rounded-2xl p-5 text-center">
                  <p className="text-4xl font-black text-[#FF4500]">45'</p>
                  <p className="text-slate-300 text-sm mt-1">Gem. reactietijd</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-5 text-center">
                  <p className="text-4xl font-black text-white">24/7</p>
                  <p className="text-slate-300 text-sm mt-1">Beschikbaar</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-5 text-center">
                  <p className="text-3xl font-black text-white">{data.priceFrom}</p>
                  <p className="text-slate-300 text-sm mt-1">Vanaf (dag)</p>
                </div>
                <div className="bg-white/10 rounded-2xl p-5 text-center">
                  <p className="text-4xl font-black text-white">4.9⭐</p>
                  <p className="text-slate-300 text-sm mt-1">1.200+ reviews</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* PROBLEMEN - klikbaar naar probleempagina */}
        <section className="py-12 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-2">Voor welk probleem heeft u een {service.name}?</h2>
            <p className="text-slate-600 mb-6">Klik op uw probleem voor directe informatie en actie</p>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
              {data.problems.map((problem, i) => (
                <Link key={i} to={beRoute(`/${problem.slug}`)} className="flex items-center justify-between bg-white border border-slate-200 hover:border-[#FF4500] hover:shadow-md p-4 rounded-xl transition-all group">
                  <div className="flex items-center gap-3">
                    {problem.urgent ? <AlertTriangle className="w-5 h-5 text-[#FF4500] flex-shrink-0" /> : <Wrench className="w-5 h-5 text-slate-400 flex-shrink-0" />}
                    <span className="font-medium text-slate-800">{problem.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {problem.urgent && <Badge className="bg-red-100 text-red-700 text-xs">Spoed</Badge>}
                    <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-[#FF4500]" />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* WAAROM SNEL HANDELEN */}
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-10 items-start">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-4">Waarom u nú moet handelen</h2>
                <div className="space-y-3">
                  {data.waarom.map((reden, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-red-50 border border-red-100 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                      <p className="text-slate-700 text-sm">{reden}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-6">
                  <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center gap-2 bg-[#FF4500] text-white px-6 py-3 rounded-full font-bold hover:bg-[#CC3700] transition-colors">
                    <Phone className="w-5 h-5" /> Bel Direct: {BE_CONFIG.contact.phoneDisplay}
                  </a>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="font-bold text-lg text-slate-900">Onze garanties</h3>
                {[
                  { icon: Clock, title: "Binnen 45 minuten", desc: "Onze vakmannen zijn gemiddeld binnen 45 minuten ter plaatse in heel België" },
                  { icon: Euro, title: "Vaste prijs, geen verrassingen", desc: `Dag: vanaf ${data.priceFrom} • Spoed/nacht: vanaf ${data.priceSpoed} • Altijd vooraf besproken` },
                  { icon: Shield, title: "Erkend & volledig verzekerd", desc: "Al onze vakmannen zijn gecertificeerd en hebben een BA-verzekering" },
                  { icon: ThumbsUp, title: "Tevredenheidsgarantie", desc: "Niet tevreden? Wij komen terug en lossen het opnieuw op zonder extra kosten" }
                ].map((item, i) => (
                  <div key={i} className="flex gap-4 p-4 border border-slate-100 rounded-xl">
                    <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-5 h-5 text-[#FF4500]" />
                    </div>
                    <div>
                      <p className="font-semibold text-slate-900">{item.title}</p>
                      <p className="text-sm text-slate-500 mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* HOE WERKT HET */}
        <section className="py-12 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">Hoe werkt een spoedinterventie?</h2>
            <div className="grid sm:grid-cols-3 gap-6">
              {[
                { step: "1", title: "Bel ons of boek online", desc: "Bereikbaar 24/7 op " + BE_CONFIG.contact.phoneDisplay + ". Binnen 2 minuten gesproken met een expert." },
                { step: "2", title: "Vakman onderweg", desc: "De dichtstbijzijnde erkende vakman vertrekt direct. U ontvangt een geschatte aankomsttijd." },
                { step: "3", title: "Probleem opgelost", desc: "Vaste prijs, transparante factuur. 80% van interventies opgelost bij eerste bezoek." }
              ].map((s, i) => (
                <div key={i} className="text-center bg-white rounded-2xl p-6 border border-slate-200">
                  <div className="w-12 h-12 bg-[#FF4500] text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-black">{s.step}</div>
                  <h3 className="font-bold text-slate-900 mb-2">{s.title}</h3>
                  <p className="text-sm text-slate-600">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* STEDEN GRID - SEO intern linking */}
        <section className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Spoed {service.name} per provincie</h2>
            <p className="text-slate-600 mb-8">Wij zijn actief in heel België. Klik op uw gemeente voor lokale informatie en directe hulp.</p>
            {Object.entries(citiesByProvince).map(([province, cities]) => (
              <div key={province} className="mb-8">
                <h3 className="font-bold text-slate-700 mb-3 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#FF4500]" /> {province}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {cities.map(city => (
                    <Link
                      key={city.slug}
                      to={beRoute(`/spoed-${serviceSlug}/${city.slug}`)}
                      className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-full text-sm text-slate-700 hover:bg-[#FF4500] hover:text-white hover:border-[#FF4500] transition-all"
                    >
                      {service.name} {city.name}
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* FAQ - Schema.org geoptimaliseerd */}
        <section className="py-12 bg-slate-50">
          <div className="max-w-3xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-8">Veelgestelde vragen over spoed {service.name}</h2>
            <div className="space-y-4">
              {data.faq.map((item, i) => (
                <div key={i} className="bg-white border border-slate-200 rounded-xl p-5">
                  <h3 className="font-semibold text-slate-900 mb-2">{item.q}</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">{item.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CROSS-SELL naar andere dienst */}
        <section className="py-10 bg-white border-t">
          <div className="max-w-7xl mx-auto px-4">
            <div className="bg-slate-50 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
              <div>
                <p className="text-sm text-slate-500 mb-1">Ook beschikbaar via SOSPro.be</p>
                <h3 className="font-bold text-lg text-slate-900">
                  {serviceSlug === 'elektricien' ? '🔧 Ook spoedloodgieter nodig?' : '⚡ Ook spoed elektricien nodig?'}
                </h3>
                <p className="text-slate-600 text-sm mt-1">Één platform, twee diensten. Bespaar tijd met één oproep.</p>
              </div>
              <Link
                to={beRoute(`/dienst/${serviceSlug === 'elektricien' ? 'loodgieter' : 'elektricien'}`)}
                className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-full font-bold whitespace-nowrap hover:bg-slate-800 transition-colors"
              >
                {serviceSlug === 'elektricien' ? 'Spoed Loodgieter' : 'Spoed Elektricien'} <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* CTA FINAL */}
        <section className="py-14 bg-[#FF4500]">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-black text-white mb-3">Heeft u nu een {service.name} nodig?</h2>
            <p className="text-white/90 text-lg mb-8">24/7 beschikbaar — ook vanavond, in het weekend en op feestdagen</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-white text-[#FF4500] px-8 py-4 rounded-full font-black text-xl hover:bg-slate-100 transition-colors">
                <Phone className="w-6 h-6" /> {BE_CONFIG.contact.phoneDisplay}
              </a>
              <Link to={beRoute(`/boek?service=${serviceSlug}&emergency=true`)} className="inline-flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-800 transition-colors">
                Online Boeken <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
            <p className="text-white/70 text-sm mt-4">Geen voorrijkosten • Vaste prijs • Erkende vakmannen</p>
          </div>
        </section>

        {/* FOOTER mini */}
        <footer className="bg-slate-900 text-slate-400 py-6">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
            <div className="flex items-center gap-2 text-white">
              <Zap className="w-5 h-5 text-[#FF4500]" />
              <span>SOSPro<span className="text-[#FF4500]">.be</span></span>
            </div>
            <div className="flex gap-4">
              <Link to={beRoute("/")} className="hover:text-white">Home</Link>
              <Link to={beRoute(`/dienst/${serviceSlug === 'elektricien' ? 'loodgieter' : 'elektricien'}`)} className="hover:text-white">{serviceSlug === 'elektricien' ? 'Loodgieter' : 'Elektricien'}</Link>
              <Link to={beRoute("/prijzen")} className="hover:text-white">Prijzen</Link>
              <Link to={beRoute("/over-ons")} className="hover:text-white">Over ons</Link>
            </div>
            <p>© 2026 SOSPro.be — 24/7 Spoed {service.name} België</p>
          </div>
        </footer>
      </div>
    </>
  );
}
