import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Phone, CheckCircle, ArrowRight, MapPin, AlertTriangle, Clock, Shield, Star, Zap, Droplet, Euro } from "lucide-react";
import { BE_CONFIG, beRoute } from "@/config/belgiumConfig";

// Alle Leuven deelgemeenten — SEO dominantie
const LEUVEN_WIJKEN = [
  { name: "Heverlee", slug: "heverlee", note: "KULeuven campus" },
  { name: "Kessel-Lo", slug: "kessel-lo", note: "Grootste deelgemeente" },
  { name: "Wilsele", slug: "wilsele", note: "Noord-Leuven" },
  { name: "Wijgmaal", slug: "wijgmaal", note: "Langs de Dijle" },
  { name: "Herent", slug: "herent", note: "Grenzend aan Leuven" },
  { name: "Rotselaar", slug: "rotselaar", note: "Vlaams-Brabant" },
  { name: "Oud-Heverlee", slug: "oud-heverlee", note: "Zuid-Leuven" },
  { name: "Bierbeek", slug: "bierbeek", note: "Oost-Leuven" },
  { name: "Bertem", slug: "bertem", note: "West-Leuven" },
  { name: "Holsbeek", slug: "holsbeek", note: "Noordoost" },
  { name: "Lubbeek", slug: "lubbeek", note: "Oost-Brabant" },
  { name: "Korbeek-Lo", slug: "korbeek-lo", note: "Bierbeek" },
];

const LEUVEN_PROBLEMEN = [
  { probleem: "Waterleiding gebarsten", slug: "lekkage-spoed", service: "loodgieter", urgent: true },
  { probleem: "Lekkage in kelder of badkamer", slug: "lekkage-spoed", service: "loodgieter", urgent: true },
  { probleem: "Toilet of WC verstopt", slug: "toilet-verstopt-spoed", service: "loodgieter", urgent: true },
  { probleem: "Boiler of cv-ketel defect", slug: "lekkage-spoed", service: "loodgieter", urgent: true },
  { probleem: "Riool verstopt Leuven", slug: "toilet-verstopt-spoed", service: "loodgieter", urgent: false },
  { probleem: "Stroomstoring of stroomuitval", slug: "stroomstoring-spoed", service: "elektricien", urgent: true },
  { probleem: "Kortsluiting of vonkend stopcontact", slug: "kortsluiting-spoed", service: "elektricien", urgent: true },
  { probleem: "Differentieel uitgeschakeld", slug: "stroomstoring-spoed", service: "elektricien", urgent: true },
  { probleem: "Zekeringkast defect", slug: "stroomstoring-spoed", service: "elektricien", urgent: false },
];

export default function BelgianLeuvenPage() {
  const localBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "SOSPro.be — Spoed Loodgieter & Elektricien Leuven",
    "description": "24/7 spoedloodgieter en spoedelektricien in Leuven, Heverlee, Kessel-Lo, Wilsele en omgeving. Binnen 45 minuten ter plaatse. Geen voorrijkosten.",
    "url": "https://sospro.be/spoed-loodgieter/leuven",
    "telephone": BE_CONFIG.contact.phone,
    "openingHours": "Mo-Su 00:00-24:00",
    "priceRange": "Vanaf €89",
    "areaServed": [
      { "@type": "City", "name": "Leuven" },
      { "@type": "City", "name": "Heverlee" },
      { "@type": "City", "name": "Kessel-Lo" },
      { "@type": "City", "name": "Wilsele" },
      { "@type": "City", "name": "Wijgmaal" },
      { "@type": "City", "name": "Herent" }
    ],
    "geo": { "@type": "GeoCoordinates", "latitude": 50.8798, "longitude": 4.7005 },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "312",
      "bestRating": "5"
    }
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Hoe snel komt een spoedloodgieter in Leuven?",
        "acceptedAnswer": { "@type": "Answer", "text": "Onze loodgieters zijn gemiddeld binnen 45 minuten ter plaatse in Leuven centrum, Heverlee, Kessel-Lo en Wilsele. Ook in de nacht en het weekend." }
      },
      {
        "@type": "Question",
        "name": "Werkt SOSPro.be ook in Heverlee, Kessel-Lo en Wilsele?",
        "acceptedAnswer": { "@type": "Answer", "text": "Ja. Wij zijn actief in heel Leuven en alle deelgemeenten: Heverlee, Kessel-Lo, Wilsele, Wijgmaal, Herent, Rotselaar, Oud-Heverlee, Bierbeek, Bertem, Holsbeek en Lubbeek." }
      },
      {
        "@type": "Question",
        "name": "Wat kost een spoedloodgieter in Leuven 's nachts?",
        "acceptedAnswer": { "@type": "Answer", "text": "Nachttarief (22u-8u): vanaf €139. Avond/weekend: vanaf €119. Overdag (8u-18u): vanaf €89. Altijd vaste prijs, geen voorrijkosten." }
      },
      {
        "@type": "Question",
        "name": "Hebben jullie ook een elektricien in Leuven?",
        "acceptedAnswer": { "@type": "Answer", "text": "Ja! SOSPro.be heeft zowel loodgieters als elektriciens in Leuven beschikbaar 24/7. Één oproep voor beide diensten." }
      },
      {
        "@type": "Question",
        "name": "Werken jullie ook voor studenten en KU Leuven campus in Heverlee?",
        "acceptedAnswer": { "@type": "Answer", "text": "Ja, wij helpen particulieren, studenten en bedrijven in heel Leuven — ook op de KU Leuven campus in Heverlee en studentenwoningen in het centrum." }
      }
    ]
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://sospro.be" },
      { "@type": "ListItem", "position": 2, "name": "Spoed Loodgieter", "item": "https://sospro.be/dienst/loodgieter" },
      { "@type": "ListItem", "position": 3, "name": "Spoed Loodgieter Leuven", "item": "https://sospro.be/spoed-loodgieter/leuven" }
    ]
  };

  return (
    <>
      <Helmet>
        <title>Spoed Loodgieter Leuven 24/7 | Heverlee, Kessel-Lo, Wilsele | SOSPro.be</title>
        <meta name="description" content="Spoedloodgieter nodig in Leuven? ✓ 24/7 beschikbaar ✓ Binnen 45 min in Leuven, Heverlee, Kessel-Lo & Wilsele ✓ Geen voorrijkosten ✓ Vaste prijs vanaf €89. Bel NU: 03 808 47 47" />
        <meta name="keywords" content="loodgieter Leuven,spoed loodgieter Leuven,loodgieter Heverlee,loodgieter Kessel-Lo,loodgieter Wilsele,loodgieter dringend Leuven,lekkage Leuven,verstopping Leuven,loodgieter 24/7 Leuven" />
        <link rel="canonical" href="https://sospro.be/spoed-loodgieter/leuven" />
        <meta property="og:title" content="Spoed Loodgieter Leuven 24/7 | SOSPro.be" />
        <meta property="og:description" content="Binnen 45 min in Leuven, Heverlee, Kessel-Lo & Wilsele. Geen voorrijkosten. Bel: 03 808 47 47" />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">{JSON.stringify(localBusinessSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(breadcrumbSchema)}</script>
      </Helmet>

      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <Link to={beRoute("/")} className="flex items-center gap-2">
              <div className="w-9 h-9 bg-[#FF4500] rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-lg">SOSPro<span className="text-[#FF4500]">.be</span></span>
            </Link>
            <div className="flex items-center gap-3">
              <Link to={beRoute("/spoed-elektricien/leuven")} className="hidden md:block text-sm font-medium text-slate-600 hover:text-[#FF4500]">
                ⚡ Ook elektricien in Leuven →
              </Link>
              <a href={`tel:${BE_CONFIG.contact.phone}`} className="flex items-center gap-2 bg-[#FF4500] text-white px-4 py-2.5 rounded-full font-bold hover:bg-[#CC3700]">
                <Phone className="w-4 h-4" /> {BE_CONFIG.contact.phoneDisplay}
              </a>
            </div>
          </div>
        </header>

        {/* Breadcrumb */}
        <nav className="bg-slate-50 border-b text-sm">
          <div className="max-w-7xl mx-auto px-4 py-2 flex items-center gap-2 text-slate-500">
            <Link to={beRoute("/")} className="hover:text-[#FF4500]">Home</Link>
            <span>/</span>
            <Link to={beRoute("/dienst/loodgieter")} className="hover:text-[#FF4500]">Spoed Loodgieter</Link>
            <span>/</span>
            <span className="text-slate-900 font-medium">Leuven</span>
          </div>
        </nav>

        {/* HERO — SEA-geoptimaliseerd voor "loodgieter Leuven dringend" */}
        <section className="bg-slate-900 text-white py-12 md:py-16">
          <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-[#FF4500] px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
                <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                <MapPin className="w-3 h-3" /> Nu beschikbaar in Leuven & omgeving
              </div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-black leading-tight mb-4">
                Spoed Loodgieter Leuven<br />
                <span className="text-[#FF4500]">24/7 — Binnen 45 Min</span><br />
                <span className="text-xl font-semibold text-slate-300">Heverlee · Kessel-Lo · Wilsele · Wijgmaal</span>
              </h1>
              <p className="text-slate-300 text-lg mb-6">
                Waterlek, verstopping, boiler defect? Onze erkende spoedloodgieters zijn 24/7 inzetbaar in <strong className="text-white">Leuven centrum, Heverlee, Kessel-Lo, Wilsele</strong> en alle omliggende gemeenten.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 mb-5">
                <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-[#FF4500] text-white px-6 py-4 rounded-full font-black text-xl hover:bg-[#CC3700]">
                  <Phone className="w-6 h-6" /> {BE_CONFIG.contact.phoneDisplay}
                </a>
                <Link to={beRoute("/boek?service=loodgieter&city=leuven&emergency=true")} className="inline-flex items-center justify-center gap-2 bg-white text-slate-900 px-6 py-4 rounded-full font-bold hover:bg-slate-100">
                  Online Boeken <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
              <div className="flex flex-wrap gap-4 text-sm text-slate-300">
                <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" />Binnen 45 min in Leuven</span>
                <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" />Geen voorrijkosten</span>
                <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" />Vaste prijs vanaf €89</span>
                <span className="flex items-center gap-1.5"><CheckCircle className="w-4 h-4 text-green-400" />Erkend & KBO-ingeschreven</span>
              </div>
            </div>
            <div className="hidden md:grid grid-cols-2 gap-3">
              {[
                { val: "45'", label: "Reactietijd Leuven" },
                { val: "24/7", label: "Beschikbaar" },
                { val: "€89", label: "Vanaf (dag)" },
                { val: "4.9⭐", label: "312 reviews" },
                { val: "12+", label: "Deelgemeenten" },
                { val: "100%", label: "Erkend" }
              ].map((s, i) => (
                <div key={i} className="bg-white/10 rounded-xl p-4 text-center">
                  <p className="text-2xl font-black">{s.val}</p>
                  <p className="text-slate-400 text-xs mt-1">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* URGENCY STRIP */}
        <div className="bg-[#FF4500] text-white py-2.5 text-center text-sm font-bold">
          ⚠️ Waterlek in Leuven? Sluit de hoofdkraan af en bel <a href={`tel:${BE_CONFIG.contact.phone}`} className="underline">{BE_CONFIG.contact.phoneDisplay}</a> — ook 's nachts en in het weekend
        </div>

        {/* PROBLEMEN — klikbaar naar probleempagina's */}
        <section className="py-10 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Voor welk probleem heeft u een loodgieter of elektricien in Leuven?</h2>
            <p className="text-slate-600 mb-6 text-sm">Klik op uw probleem voor directe info en actie</p>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
              {LEUVEN_PROBLEMEN.map((item, i) => (
                <Link key={i} to={beRoute(`/${item.slug}`)} className="flex items-center justify-between bg-white border border-slate-200 hover:border-[#FF4500] hover:shadow-sm p-4 rounded-xl transition-all group">
                  <div className="flex items-center gap-3">
                    {item.urgent ? <AlertTriangle className="w-5 h-5 text-[#FF4500] flex-shrink-0" /> : <Droplet className="w-5 h-5 text-blue-400 flex-shrink-0" />}
                    <div>
                      <p className="font-medium text-slate-800 text-sm">{item.probleem}</p>
                      <p className="text-xs text-slate-400">{item.service === "loodgieter" ? "🔧 Loodgieter" : "⚡ Elektricien"}</p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-[#FF4500]" />
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* LEUVEN WIJKEN — de sleutel tot GEO-dominantie */}
        <section className="py-10 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Spoed Loodgieter & Elektricien in alle wijken van Leuven</h2>
            <p className="text-slate-600 text-sm mb-6">Van Leuven centrum tot Heverlee, Kessel-Lo en Wilsele — wij dekken heel groot-Leuven</p>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
              {LEUVEN_WIJKEN.map((wijk, i) => (
                <div key={i} className="border border-slate-100 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <MapPin className="w-4 h-4 text-[#FF4500]" />
                    <h3 className="font-bold text-slate-900">{wijk.name}</h3>
                    <span className="text-xs text-slate-400">{wijk.note}</span>
                  </div>
                  <div className="flex gap-2">
                    <Link to={beRoute(`/spoed-loodgieter/${wijk.slug}`)} className="flex-1 text-center py-2 bg-blue-50 text-blue-700 rounded-lg text-xs font-medium hover:bg-blue-100 transition-colors">
                      🔧 Loodgieter
                    </Link>
                    <Link to={beRoute(`/spoed-elektricien/${wijk.slug}`)} className="flex-1 text-center py-2 bg-yellow-50 text-yellow-700 rounded-lg text-xs font-medium hover:bg-yellow-100 transition-colors">
                      ⚡ Elektricien
                    </Link>
                  </div>
                </div>
              ))}
              {/* Leuven centrum zelf */}
              <div className="border-2 border-[#FF4500] rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <MapPin className="w-4 h-4 text-[#FF4500]" />
                  <h3 className="font-bold text-slate-900">Leuven Centrum</h3>
                  <span className="text-xs text-[#FF4500] font-medium">Hoofdstad</span>
                </div>
                <div className="flex gap-2">
                  <Link to={beRoute("/spoed-loodgieter/leuven")} className="flex-1 text-center py-2 bg-[#FF4500] text-white rounded-lg text-xs font-medium">
                    🔧 Loodgieter
                  </Link>
                  <Link to={beRoute("/spoed-elektricien/leuven")} className="flex-1 text-center py-2 bg-slate-900 text-white rounded-lg text-xs font-medium">
                    ⚡ Elektricien
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* WAAROM SOSPRO vs CONCURRENTIE LEUVEN */}
        <section className="py-10 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Waarom SOSPro.be in Leuven?</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {[
                { title: "Loodgieter + Elektricien — één oproep", desc: "Uniek in Leuven: waterlek én stroomprobleem? Wij sturen de juiste vakman of regelen beide tegelijk. Geen doorverwijzing." },
                { title: "Geen voorrijkosten — ook naar Heverlee & Kessel-Lo", desc: "Tegenstanders rekenen extra aan voor deelgemeenten. Wij niet. Leuven, Heverlee, Kessel-Lo, Wilsele: zelfde eerlijke prijs." },
                { title: "Sneller dan lokale concurrentie", desc: "Heat Solutions, Hooylaerts, ProLoodgieter: goede vakmans maar geen 24/7 garantie. Wij zijn élk uur van de dag bereikbaar." },
                { title: "Erkend & volledig verzekerd in Vlaams-Brabant", desc: "Al onze loodgieters zijn KBO-ingeschreven, CERGA/erkend voor gasinstallaties en hebben een BA-verzekering voor alle werken." },
                { title: "Geschikt voor studenten & KU Leuven campus", desc: "Studentenwoning in Leuven centrum of kot in Heverlee? Geen probleem — ook kleine interventies, ook 's avonds laat." },
                { title: "Gratis bellen via internet", desc: "Bel ons gratis via onze website-app — ook als u geen beltegoed meer heeft. Uniek in de Leuvense spoedmarkt." }
              ].map((item, i) => (
                <div key={i} className="flex gap-3 p-4 bg-white border border-slate-100 rounded-xl">
                  <CheckCircle className="w-5 h-5 text-[#FF4500] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-slate-900 text-sm">{item.title}</p>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* PRIJZEN LEUVEN */}
        <section className="py-10 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Tarieven loodgieter Leuven 2026</h2>
            <p className="text-slate-600 text-sm mb-6">Transparant, geen voorrijkosten, altijd vaste prijs voor aanvang</p>
            <div className="grid sm:grid-cols-3 gap-4 max-w-2xl">
              {[
                { label: "Overdag", time: "Ma–vr 8u–18u", price: "€89", note: "meest gevraagd" },
                { label: "Avond & weekend", time: "18u–22u, za–zo", price: "€119", note: "spoedtarief", best: true },
                { label: "Nacht & feestdag", time: "22u–8u", price: "€139", note: "nacht tarief" }
              ].map((p, i) => (
                <div key={i} className={`p-5 rounded-xl border-2 ${p.best ? "border-[#FF4500] bg-orange-50" : "border-slate-200"}`}>
                  {p.best && <span className="inline-block mb-2 text-xs bg-[#FF4500] text-white px-2 py-0.5 rounded-full">Meest gevraagd</span>}
                  <p className="font-bold text-slate-900">{p.label}</p>
                  <p className="text-xs text-slate-400 mb-2">{p.time}</p>
                  <p className="text-3xl font-black text-slate-900">{p.price}</p>
                  <p className="text-xs text-slate-400 mt-1">per interventie • {p.note}</p>
                </div>
              ))}
            </div>
            <p className="mt-4 text-xs text-slate-400">* Geen voorrijkosten. Materialen apart na akkoord. Extra uren: €60/u.</p>
          </div>
        </section>

        {/* FAQ — schema.org geoptimaliseerd voor "loodgieter leuven" featured snippet */}
        <section className="py-10 bg-slate-50">
          <div className="max-w-3xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Veelgestelde vragen — loodgieter Leuven</h2>
            <div className="space-y-4">
              {[
                { q: "Hoe snel komt een spoedloodgieter in Leuven?", a: "Gemiddeld binnen 45 minuten na uw oproep in Leuven centrum. In Heverlee, Kessel-Lo en Wilsele iets langer afhankelijk van de beschikbaarheid, maar altijd binnen het uur." },
                { q: "Werkt SOSPro.be ook in Heverlee, Kessel-Lo en Wilsele?", a: "Ja. Wij zijn actief in heel groot-Leuven: Leuven centrum, Heverlee (KU Leuven campus), Kessel-Lo, Wilsele, Wijgmaal, Herent, Rotselaar, Oud-Heverlee, Bierbeek, Bertem en omgeving." },
                { q: "Wat kost een spoedloodgieter in Leuven 's nachts?", a: "Nacht (22u–8u) en feestdagen: vanaf €139 per interventie. Avond en weekend (18u–22u, za–zo): vanaf €119. Overdag (ma–vr 8u–18u): vanaf €89. Altijd vaste prijs, geen voorrijkosten." },
                { q: "Hebben jullie ook een erkende elektricien in Leuven?", a: "Ja! Naast onze spoedloodgieters hebben wij ook AREI-erkende elektriciens beschikbaar in Leuven en omgeving, 24/7. Één telefoonnummer voor beide diensten: 03 808 47 47." },
                { q: "Werken jullie voor studenten in Leuven?", a: "Absoluut. Wij helpen studenten in koten en studentenwoningen in Leuven centrum, Heverlee (campus) en Kessel-Lo. Ook kleine interventies en ook laat op de avond." },
                { q: "Wat doe ik bij een waterlek in Leuven terwijl ik wacht?", a: "Sluit de hoofdkraan af (meestal in de kelder of meterkast). Schakel elektriciteit uit in de buurt van het lek. Bel 03 808 47 47 — onze loodgieter geeft gratis telefonisch advies terwijl hij onderweg is." }
              ].map((item, i) => (
                <div key={i} className="bg-white border border-slate-200 rounded-xl p-5">
                  <h3 className="font-semibold text-slate-900 mb-2 text-sm">{item.q}</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">{item.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CROSS-SELL elektricien Leuven */}
        <section className="py-8 bg-white border-t">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-6 bg-slate-50 rounded-2xl border border-slate-200">
              <div>
                <p className="text-sm text-slate-500">Ook beschikbaar in Leuven</p>
                <h3 className="font-bold text-lg text-slate-900">⚡ Spoed Elektricien Leuven nodig?</h3>
                <p className="text-slate-600 text-sm">Stroomstoring, kortsluiting of differentieel? Wij hebben ook erkende elektriciens in Leuven, 24/7.</p>
              </div>
              <Link to={beRoute("/spoed-elektricien/leuven")} className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-full font-bold whitespace-nowrap hover:bg-slate-800">
                Spoed Elektricien Leuven <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* CTA FINAL */}
        <section className="py-14 bg-[#FF4500]">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-black text-white mb-2">Direct een loodgieter in Leuven?</h2>
            <p className="text-white/90 mb-2">24/7 beschikbaar — ook vanavond, weekend en feestdagen</p>
            <p className="text-white/70 text-sm mb-8">Leuven · Heverlee · Kessel-Lo · Wilsele · Wijgmaal · Herent</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-white text-[#FF4500] px-8 py-4 rounded-full font-black text-xl hover:bg-slate-100">
                <Phone className="w-6 h-6" /> {BE_CONFIG.contact.phoneDisplay}
              </a>
              <Link to={beRoute("/boek?service=loodgieter&city=leuven&emergency=true")} className="inline-flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-800">
                Online Boeken <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
            <p className="text-white/70 text-sm mt-4">Geen voorrijkosten • Vaste prijs • Erkende vakmannen in Leuven</p>
          </div>
        </section>

        <footer className="bg-slate-900 text-slate-400 py-6">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
            <Link to={beRoute("/")} className="text-white font-bold">SOSPro<span className="text-[#FF4500]">.be</span></Link>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to={beRoute("/dienst/loodgieter")} className="hover:text-white">Alle steden</Link>
              <Link to={beRoute("/spoed-elektricien/leuven")} className="hover:text-white">Elektricien Leuven</Link>
              <Link to={beRoute("/prijzen")} className="hover:text-white">Prijzen</Link>
              <Link to={beRoute("/over-ons")} className="hover:text-white">Over ons</Link>
            </div>
            <p>© 2026 SOSPro.be — Loodgieter Leuven 24/7</p>
          </div>
        </footer>
      </div>
    </>
  );
}
