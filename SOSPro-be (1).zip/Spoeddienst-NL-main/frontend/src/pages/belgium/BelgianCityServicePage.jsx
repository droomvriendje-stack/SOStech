import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Phone, Clock, Shield, CheckCircle, ArrowRight, MapPin, Star, AlertTriangle, Euro, Zap, Droplet } from "lucide-react";
import { BE_CONFIG, BELGIAN_CITIES, BELGIAN_SERVICES, beRoute } from "@/config/belgiumConfig";

const SERVICE_ICON = { elektricien: "⚡", loodgieter: "🔧", slotenmaker: "🔐" };
const SERVICE_COLOR = { elektricien: "from-yellow-400 to-orange-500", loodgieter: "from-blue-500 to-blue-600", slotenmaker: "from-slate-600 to-slate-700" };

export default function BelgianCityServicePage() {
  const { citySlug } = useParams();
  const path = window.location.pathname;
  const serviceSlug = path.includes("elektricien") ? "elektricien" : path.includes("loodgieter") ? "loodgieter" : "slotenmaker";

  const city = BELGIAN_CITIES.find(c => c.slug === citySlug);
  const service = BELGIAN_SERVICES.find(s => s.slug === serviceSlug);

  if (!city || !service) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Pagina niet gevonden</h1>
          <Link to={beRoute("/")} className="text-[#FF4500] hover:underline">← Terug naar home</Link>
        </div>
      </div>
    );
  }

  const cityName = city.name;
  const serviceName = service.name;
  const priceFrom = `€${service.priceFrom}`;
  const priceSpoed = `€${service.priceSpoed}`;
  const nearbyCities = BELGIAN_CITIES.filter(c => c.province === city.province && c.slug !== city.slug).slice(0, 8);
  const otherService = BELGIAN_SERVICES.find(s => s.slug !== serviceSlug && s.slug !== "slotenmaker");

  // Schema.org LocalBusiness per stad — GEO dominant
  const localBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": `SOSPro.be — Spoed ${serviceName} ${cityName}`,
    "description": `24/7 spoed ${serviceName.toLowerCase()} in ${cityName}. Binnen 45 minuten ter plaatse. Erkend, verzekerd, vaste prijs.`,
    "url": `https://sospro.be/spoed-${serviceSlug}/${citySlug}`,
    "telephone": BE_CONFIG.contact.phone,
    "email": BE_CONFIG.contact.email,
    "openingHours": "Mo-Su 00:00-24:00",
    "areaServed": {
      "@type": "City",
      "name": cityName,
      "addressCountry": "BE"
    },
    "geo": city.lat ? {
      "@type": "GeoCoordinates",
      "latitude": city.lat,
      "longitude": city.lng
    } : undefined,
    "priceRange": `Vanaf ${priceFrom}`,
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "reviewCount": "1247",
      "bestRating": "5"
    },
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": `Spoed ${serviceName} diensten ${cityName}`,
      "itemListElement": [
        {
          "@type": "Offer",
          "name": `Spoed ${serviceName} ${cityName} — overdag`,
          "price": service.priceFrom,
          "priceCurrency": "EUR",
          "availability": "https://schema.org/InStock"
        },
        {
          "@type": "Offer",
          "name": `Spoed ${serviceName} ${cityName} — nacht/weekend`,
          "price": service.priceSpoed,
          "priceCurrency": "EUR",
          "availability": "https://schema.org/InStock"
        }
      ]
    }
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://sospro.be" },
      { "@type": "ListItem", "position": 2, "name": `Spoed ${serviceName}`, "item": `https://sospro.be/dienst/${serviceSlug}` },
      { "@type": "ListItem", "position": 3, "name": `Spoed ${serviceName} ${cityName}`, "item": `https://sospro.be/spoed-${serviceSlug}/${citySlug}` }
    ]
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": `Hoe snel komt een ${serviceName.toLowerCase()} in ${cityName}?`,
        "acceptedAnswer": { "@type": "Answer", "text": `Onze spoedvakmannen zijn gemiddeld binnen 45 minuten ter plaatse in ${cityName} en omgeving. Bij zeer dringende situaties proberen wij dit te versnellen.` }
      },
      {
        "@type": "Question",
        "name": `Wat kost een spoed ${serviceName.toLowerCase()} in ${cityName}?`,
        "acceptedAnswer": { "@type": "Answer", "text": `Overdag: vanaf ${priceFrom}. Spoed/nacht/weekend: vanaf ${priceSpoed}. Altijd een vaste prijs, geen verborgen kosten of voorrijkosten.` }
      },
      {
        "@type": "Question",
        "name": `Werkt u ook 's nachts en in het weekend in ${cityName}?`,
        "acceptedAnswer": { "@type": "Answer", "text": `Ja, wij zijn 24 uur per dag, 7 dagen per week bereikbaar in ${cityName} — ook op feestdagen en tijdens het weekend.` }
      }
    ]
  };

  return (
    <>
      <Helmet>
        <title>Spoed {serviceName} {cityName} | 24/7 Binnen 45 Min | SOSPro.be</title>
        <meta name="description" content={`Spoed ${serviceName.toLowerCase()} nodig in ${cityName}? ✓ 24/7 beschikbaar ✓ Binnen 45 minuten ter plaatse ✓ Erkend & verzekerd ✓ Vaste prijs ${priceFrom}. Bel NU: 03 808 47 47`} />
        <link rel="canonical" href={`https://sospro.be/spoed-${serviceSlug}/${citySlug}`} />
        <meta property="og:title" content={`Spoed ${serviceName} ${cityName} — 24/7 SOSPro.be`} />
        <meta property="og:description" content={`Binnen 45 minuten een erkende ${serviceName.toLowerCase()} in ${cityName}. Bel: 03 808 47 47`} />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">{JSON.stringify(localBusinessSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(breadcrumbSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
      </Helmet>

      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <Link to={beRoute("/")} className="flex items-center gap-2">
              <div className="w-9 h-9 bg-[#FF4500] rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-lg">SOSPro<span className="text-[#FF4500]">.be</span></span>
            </Link>
            <a href={`tel:${BE_CONFIG.contact.phone}`} className="flex items-center gap-2 bg-[#FF4500] text-white px-4 py-2.5 rounded-full font-bold hover:bg-[#CC3700]">
              <Phone className="w-4 h-4" /> {BE_CONFIG.contact.phoneDisplay}
            </a>
          </div>
        </header>

        {/* Breadcrumb */}
        <nav className="bg-slate-50 border-b text-sm" aria-label="Breadcrumb">
          <div className="max-w-7xl mx-auto px-4 py-2 flex items-center gap-2 text-slate-500">
            <Link to={beRoute("/")} className="hover:text-[#FF4500]">Home</Link>
            <span>/</span>
            <Link to={beRoute(`/dienst/${serviceSlug}`)} className="hover:text-[#FF4500]">Spoed {serviceName}</Link>
            <span>/</span>
            <span className="text-slate-900 font-medium">Spoed {serviceName} {cityName}</span>
          </div>
        </nav>

        {/* HERO — stad-specifiek, hoge urgentie */}
        <section className="bg-slate-900 text-white py-12 md:py-16">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="inline-flex items-center gap-2 bg-[#FF4500] text-white text-sm font-medium px-4 py-1.5 rounded-full mb-4">
                  <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                  <MapPin className="w-3 h-3" /> Nu beschikbaar in {cityName}
                </div>
                <h1 className="text-3xl md:text-4xl font-black leading-tight mb-3">
                  Spoed {serviceName} {cityName}<br />
                  <span className="text-[#FF4500]">24/7 — Binnen 45 Minuten</span>
                </h1>
                <p className="text-slate-300 text-lg mb-6">
                  {service.tagline} Onze erkende vakmannen zijn nu inzetbaar in {cityName} en omliggende gemeenten.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 mb-5">
                  <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-[#FF4500] text-white px-6 py-3.5 rounded-full font-bold text-lg hover:bg-[#CC3700]">
                    <Phone className="w-5 h-5" /> Bel Nu: {BE_CONFIG.contact.phoneDisplay}
                  </a>
                  <Link to={beRoute(`/boek?service=${serviceSlug}&city=${citySlug}`)} className="inline-flex items-center justify-center gap-2 bg-white text-slate-900 px-6 py-3.5 rounded-full font-bold hover:bg-slate-100">
                    Online Boeken <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
                <div className="flex flex-wrap gap-3">
                  {["Binnen 45 min", "Geen voorrijkosten", `Vanaf ${priceFrom}`, "Erkend AREI/KBO"].map((u, i) => (
                    <span key={i} className="flex items-center gap-1.5 text-sm text-slate-300">
                      <CheckCircle className="w-3.5 h-3.5 text-green-400" /> {u}
                    </span>
                  ))}
                </div>
              </div>
              <div className="hidden md:grid grid-cols-3 gap-3">
                {[
                  { val: "45'", label: "Reactietijd" },
                  { val: "24/7", label: "Beschikbaar" },
                  { val: priceFrom, label: "Vanaf (dag)" },
                  { val: "4.9⭐", label: "Score" },
                  { val: "12k+", label: "Interventies" },
                  { val: "100%", label: "Erkend" },
                ].map((s, i) => (
                  <div key={i} className="bg-white/10 rounded-xl p-4 text-center">
                    <p className="text-2xl font-black text-white">{s.val}</p>
                    <p className="text-slate-400 text-xs mt-1">{s.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* URGENCY STRIP */}
        <div className="bg-[#FF4500] text-white py-3 text-center">
          <p className="font-bold text-sm">⚠️ In nood? Elke minuut telt — <a href={`tel:${BE_CONFIG.contact.phone}`} className="underline">{BE_CONFIG.contact.phoneDisplay}</a> — 24/7 bereikbaar in {cityName}</p>
        </div>

        {/* HOE WERKT HET */}
        <section className="py-10 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6 text-center">Hoe snel zijn wij bij u in {cityName}?</h2>
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                { step: "1", icon: Phone, title: "U belt", desc: `Bel ${BE_CONFIG.contact.phoneDisplay} — binnen 2 min spreekt u met een expert` },
                { step: "2", icon: MapPin, title: "Vakman vertrekt", desc: `De dichtstbijzijnde erkende ${serviceName.toLowerCase()} in ${city.province} vertrekt direct` },
                { step: "3", icon: CheckCircle, title: "Probleem opgelost", desc: "Vaste prijs, transparante factuur, tevredenheidsgarantie" }
              ].map((s, i) => (
                <div key={i} className="flex gap-4 p-5 border border-slate-200 rounded-xl">
                  <div className="w-10 h-10 bg-[#FF4500] text-white rounded-full flex items-center justify-center font-black text-lg flex-shrink-0">{s.step}</div>
                  <div>
                    <h3 className="font-bold text-slate-900 mb-1">{s.title}</h3>
                    <p className="text-sm text-slate-600">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* PRIJZEN — transparant, versla homedeal op vertrouwen */}
        <section className="py-10 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Transparante prijzen voor {serviceName.toLowerCase()} in {cityName}</h2>
            <p className="text-slate-600 mb-6">Geen verborgen kosten. Prijs altijd vooraf besproken. Geen voorrijkosten.</p>
            <div className="grid sm:grid-cols-3 gap-4 max-w-2xl">
              {[
                { label: "Overdag (8u–18u)", price: priceFrom, note: "ma–vr" },
                { label: "Avond & weekend", price: priceSpoed, note: "18u–22u, za–zo" },
                { label: "Nacht & feestdagen", price: `€${service.priceSpoed + 20}`, note: "22u–8u" }
              ].map((p, i) => (
                <div key={i} className={`p-5 rounded-xl border-2 ${i === 1 ? "border-[#FF4500] bg-orange-50" : "border-slate-200 bg-white"}`}>
                  <p className="text-sm text-slate-500 mb-1">{p.label}</p>
                  <p className="text-3xl font-black text-slate-900">{p.price}</p>
                  <p className="text-xs text-slate-400 mt-1">{p.note}</p>
                  {i === 1 && <span className="inline-block mt-2 text-xs bg-[#FF4500] text-white px-2 py-0.5 rounded-full">Meest gevraagd</span>}
                </div>
              ))}
            </div>
            <p className="mt-4 text-sm text-slate-500">* Alle prijzen zijn startprijzen per interventie incl. BTW. Materiaalkosten worden apart vermeld.</p>
          </div>
        </section>

        {/* WAAROM SOSPRO vs CONCURRENTIE */}
        <section className="py-10 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Waarom SOSPro.be in {cityName}?</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {[
                { title: "Direct aan de telefoon", desc: `U belt ${BE_CONFIG.contact.phoneDisplay} en spreekt onmiddellijk met een expert — geen call center, geen wachtrij` },
                { title: "Erkende vakmannen", desc: "Al onze elektriciens zijn AREI-conform gecertificeerd. Loodgieters zijn ingeschreven bij de KBO en volledig verzekerd" },
                { title: "Geen doorverkoop van uw lead", desc: "Wij zijn de dienstverlener zelf — geen platform dat uw aanvraag doorverkoopt aan 5 andere bedrijven zoals Homedeal" },
                { title: `Lokale kennis van ${cityName}`, desc: `Onze vakmannen kennen ${cityName} en ${city.province} van binnen en buiten — korte rijtijden, snelle aankomst` },
                { title: "Cross-interventie mogelijk", desc: `Lekkage én stroom problemen tegelijk? Wij sturen de juiste specialist of een alleskunner — één oproep voor ${city.province}` },
                { title: "Vaste prijs voor aanvang", desc: "U weet wat het kost vóór de vakman begint. Geen verrassingen achteraf, geen verborgen kosten" }
              ].map((item, i) => (
                <div key={i} className="flex gap-3 p-4 border border-slate-100 rounded-xl">
                  <CheckCircle className="w-5 h-5 text-[#FF4500] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-slate-900">{item.title}</p>
                    <p className="text-sm text-slate-500 mt-0.5">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* OMLIGGENDE GEMEENTEN — GEO intern linking voor MapPack */}
        {nearbyCities.length > 0 && (
          <section className="py-10 bg-slate-50">
            <div className="max-w-7xl mx-auto px-4">
              <h2 className="text-xl font-bold text-slate-900 mb-2">Ook beschikbaar in buurgemeenten van {cityName}</h2>
              <p className="text-slate-600 text-sm mb-4">Onze {serviceName.toLowerCase()}s zijn actief in de hele regio {city.province}</p>
              <div className="flex flex-wrap gap-2">
                {nearbyCities.map(c => (
                  <Link key={c.slug} to={beRoute(`/spoed-${serviceSlug}/${c.slug}`)}
                    className="px-3 py-1.5 bg-white border border-slate-200 rounded-full text-sm hover:bg-[#FF4500] hover:text-white hover:border-[#FF4500] transition-all">
                    {serviceName} {c.name}
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* FAQ */}
        <section className="py-10 bg-white">
          <div className="max-w-3xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Veelgestelde vragen — {serviceName} {cityName}</h2>
            <div className="space-y-4">
              {[
                { q: `Hoe snel komt een ${serviceName.toLowerCase()} in ${cityName}?`, a: `Gemiddeld binnen 45 minuten na uw oproep. In ${cityName} en omgeving van ${city.province} is de reactietijd vaak sneller dankzij ons lokale vakmansnetwerk.` },
                { q: `Wat kost een spoed ${serviceName.toLowerCase()} in ${cityName}?`, a: `Overdag: vanaf ${priceFrom}. Avond/weekend/feestdag: vanaf ${priceSpoed}. Altijd vaste prijs, geen voorrijkosten, geen verborgen kosten.` },
                { q: `Werken uw ${serviceName.toLowerCase()}s ook 's nachts in ${cityName}?`, a: `Ja, 24 uur per dag, 7 dagen per week — ook op feestdagen. Bel ${BE_CONFIG.contact.phoneDisplay}.` },
                { q: `Zijn uw vakmannen erkend in België?`, a: `Ja. ${serviceName === "Elektricien" ? "AREI-conform gecertificeerd." : "KBO-ingeschreven en volledig verzekerd."} Al onze vakmannen hebben een BA-verzekering.` },
                { q: `Werkt SOSPro.be ook voor bedrijven in ${cityName}?`, a: `Ja, wij werken voor particulieren en bedrijven (horeca, kantoren, appartementsgebouwen, VME) in ${cityName} en heel ${city.province}.` }
              ].map((item, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-5">
                  <h3 className="font-semibold text-slate-900 mb-2">{item.q}</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">{item.a}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CROSS-SELL andere dienst */}
        {otherService && (
          <section className="py-8 bg-slate-50 border-t">
            <div className="max-w-7xl mx-auto px-4">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-6 bg-white rounded-2xl border border-slate-200">
                <div>
                  <p className="text-sm text-slate-500">Naast {serviceName.toLowerCase()} ook:</p>
                  <h3 className="font-bold text-lg text-slate-900">Spoed {otherService.name} in {cityName}?</h3>
                  <p className="text-slate-600 text-sm">{otherService.tagline}</p>
                </div>
                <Link to={beRoute(`/spoed-${otherService.slug}/${citySlug}`)} className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-full font-bold hover:bg-slate-800 whitespace-nowrap">
                  Spoed {otherService.name} {cityName} <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </section>
        )}

        {/* CTA FINAL */}
        <section className="py-14 bg-[#FF4500]">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-black text-white mb-2">Direct een {serviceName} in {cityName}?</h2>
            <p className="text-white/90 mb-8">24/7 beschikbaar — ook vanavond en in het weekend</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-white text-[#FF4500] px-8 py-4 rounded-full font-black text-xl hover:bg-slate-100">
                <Phone className="w-6 h-6" /> {BE_CONFIG.contact.phoneDisplay}
              </a>
              <Link to={beRoute(`/boek?service=${serviceSlug}&city=${citySlug}&emergency=true`)} className="inline-flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-slate-800">
                Online Boeken <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
            <p className="text-white/70 text-sm mt-4">Geen voorrijkosten • Vaste prijs • Erkende vakmannen in {cityName}</p>
          </div>
        </section>

        <footer className="bg-slate-900 text-slate-400 py-6">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
            <Link to={beRoute("/")} className="text-white font-bold">SOSPro<span className="text-[#FF4500]">.be</span></Link>
            <div className="flex gap-4">
              <Link to={beRoute(`/dienst/${serviceSlug}`)} className="hover:text-white">Alle steden</Link>
              <Link to={beRoute("/prijzen")} className="hover:text-white">Prijzen</Link>
              <Link to={beRoute("/over-ons")} className="hover:text-white">Over ons</Link>
            </div>
            <p>© 2026 — Spoed {serviceName} {cityName} | SOSPro.be</p>
          </div>
        </footer>
      </div>
    </>
  );
}
