import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Phone, AlertTriangle, CheckCircle, ArrowRight, Clock, Zap, Droplet, Shield } from "lucide-react";
import { BE_CONFIG, BELGIAN_CITIES, BELGIAN_PROBLEMS, BELGIAN_SERVICES, beRoute } from "@/config/belgiumConfig";

export default function BelgianProblemPage() {
  const { slug } = useParams();
  const problem = BELGIAN_PROBLEMS[slug];

  if (!problem) {
    return (
      <div className="min-h-screen flex items-center justify-center flex-col gap-4">
        <h1 className="text-2xl font-bold">Pagina niet gevonden</h1>
        <Link to={beRoute("/")} className="text-[#FF4500] hover:underline">← Terug naar home</Link>
      </div>
    );
  }

  const service = BELGIAN_SERVICES.find(s => s.slug === problem.relatedService || s.slug === problem.service);
  const relatedCities = BELGIAN_CITIES.filter(c => c.isCapital).slice(0, 6);

  const howToSchema = {
    "@context": "https://schema.org",
    "@type": "HowTo",
    "name": problem.heroText,
    "description": problem.description,
    "step": [
      { "@type": "HowToStep", "name": "Directe actie", "text": problem.urgencyTip },
      { "@type": "HowToStep", "name": "Bel SOSPro.be", "text": `Bel onmiddellijk ${BE_CONFIG.contact.phoneDisplay} voor een erkende spoedvakman.` },
      { "@type": "HowToStep", "name": "Vakman onderweg", "text": "Binnen 45 minuten is een erkende vakman bij u ter plaatse in heel België." }
    ]
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": `Wat moet ik doen bij ${problem.title.toLowerCase()}?`,
        "acceptedAnswer": { "@type": "Answer", "text": problem.urgencyTip }
      },
      {
        "@type": "Question",
        "name": `Hoe snel komt een vakman bij ${problem.title.toLowerCase()}?`,
        "acceptedAnswer": { "@type": "Answer", "text": `Onze spoedvakmannen zijn gemiddeld binnen 45 minuten ter plaatse in heel België, 24 uur per dag.` }
      },
      {
        "@type": "Question",
        "name": `Wat kost een spoedinterventie voor ${problem.title.toLowerCase()}?`,
        "acceptedAnswer": { "@type": "Answer", "text": `Vanaf ${problem.priceFrom} overdag. 's Nachts en weekends een spoedtarief. Altijd vaste prijs, geen voorrijkosten.` }
      }
    ]
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://sospro.be" },
      service && { "@type": "ListItem", "position": 2, "name": `Spoed ${service.name}`, "item": `https://sospro.be/dienst/${service.slug}` },
      { "@type": "ListItem", "position": 3, "name": problem.title, "item": `https://sospro.be/${slug}` }
    ].filter(Boolean)
  };

  const isUrgent = ["kortsluiting-spoed", "lekkage-spoed"].includes(slug);

  return (
    <>
      <Helmet>
        <title>{problem.metaTitle}</title>
        <meta name="description" content={problem.metaDescription} />
        <link rel="canonical" href={`https://sospro.be/${slug}`} />
        <meta property="og:title" content={problem.metaTitle} />
        <meta property="og:description" content={problem.metaDescription} />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">{JSON.stringify(howToSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(breadcrumbSchema)}</script>
      </Helmet>

      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <Link to={beRoute("/")} className="flex items-center gap-2">
              <div className="w-9 h-9 bg-[#FF4500] rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-lg">SOSPro<span className="text-[#FF4500]">.be</span></span>
            </Link>
            <a href={`tel:${BE_CONFIG.contact.phone}`} className="flex items-center gap-2 bg-[#FF4500] text-white px-4 py-2.5 rounded-full font-bold hover:bg-[#CC3700]">
              <Phone className="w-4 h-4" /> {BE_CONFIG.contact.phoneDisplay}
            </a>
          </div>
        </header>

        {/* Breadcrumb */}
        <nav className="bg-slate-50 border-b text-sm">
          <div className="max-w-7xl mx-auto px-4 py-2 flex items-center gap-2 text-slate-500">
            <Link to={beRoute("/")} className="hover:text-[#FF4500]">Home</Link>
            {service && <><span>/</span><Link to={beRoute(`/dienst/${service.slug}`)} className="hover:text-[#FF4500]">Spoed {service.name}</Link></>}
            <span>/</span>
            <span className="text-slate-900 font-medium">{problem.title}</span>
          </div>
        </nav>

        {/* URGENCY BANNER voor hoog-risico problemen */}
        {isUrgent && (
          <div className="bg-red-600 text-white py-3 px-4 text-center">
            <p className="font-bold flex items-center justify-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              DIRECT ACTIE VEREIST: {problem.urgencyTip}
            </p>
          </div>
        )}

        {/* HERO */}
        <section className="bg-slate-900 text-white py-12 md:py-16">
          <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-[#FF4500] text-white text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
                <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
                24/7 Spoedinterventie België
              </div>
              <h1 className="text-3xl md:text-4xl font-black leading-tight mb-4">{problem.heroText}</h1>
              <p className="text-slate-300 text-lg mb-6">{problem.description}</p>
              <div className="flex flex-col sm:flex-row gap-3 mb-5">
                <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-[#FF4500] text-white px-6 py-3.5 rounded-full font-bold text-lg hover:bg-[#CC3700]">
                  <Phone className="w-5 h-5" /> {BE_CONFIG.contact.phoneDisplay}
                </a>
                {service && (
                  <Link to={beRoute(`/boek?probleem=${slug}&service=${service.slug}&emergency=true`)} className="inline-flex items-center justify-center gap-2 bg-white text-slate-900 px-6 py-3.5 rounded-full font-bold hover:bg-slate-100">
                    Online Boeken <ArrowRight className="w-4 h-4" />
                  </Link>
                )}
              </div>
              <div className="flex flex-wrap gap-3">
                {["Binnen 45 min ter plaatse","Geen voorrijkosten",`Vanaf ${problem.priceFrom}`,"Erkend & verzekerd"].map((u, i) => (
                  <span key={i} className="flex items-center gap-1.5 text-sm text-slate-300">
                    <CheckCircle className="w-3.5 h-3.5 text-green-400" /> {u}
                  </span>
                ))}
              </div>
            </div>
            <div className="hidden md:block">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
                <h3 className="font-bold text-lg mb-4 text-[#FF4500]">🚨 Wat nu direct doen?</h3>
                <div className="space-y-3">
                  {[
                    problem.urgencyTip,
                    `Bel onmiddellijk ${BE_CONFIG.contact.phoneDisplay} — ook 's nachts`,
                    "Onze vakman geeft telefonisch advies terwijl hij onderweg is",
                    "Gemiddeld binnen 45 minuten opgelost"
                  ].map((step, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <span className="w-6 h-6 bg-[#FF4500] rounded-full text-white text-xs flex items-center justify-center flex-shrink-0 font-bold">{i + 1}</span>
                      <p className="text-slate-300 text-sm">{step}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SYMPTOMEN */}
        <section className="py-10 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Herkent u dit? Bel onmiddellijk.</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
              {problem.symptoms.map((s, i) => (
                <div key={i} className="flex items-start gap-3 p-4 bg-white border border-red-100 rounded-xl">
                  <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <p className="text-slate-700 text-sm">{s}</p>
                </div>
              ))}
            </div>
            <div className="mt-6 text-center">
              <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center gap-2 bg-[#FF4500] text-white px-8 py-4 rounded-full font-black text-xl hover:bg-[#CC3700]">
                <Phone className="w-6 h-6" /> Bel Nu: {BE_CONFIG.contact.phoneDisplay}
              </a>
            </div>
          </div>
        </section>

        {/* OPLOSSINGEN */}
        <section className="py-10 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Wat doen onze vakmannen bij {problem.title.toLowerCase()}?</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {problem.solutions.map((sol, i) => (
                <div key={i} className="flex items-start gap-3 p-4 border border-slate-100 rounded-xl">
                  <CheckCircle className="w-5 h-5 text-[#FF4500] flex-shrink-0 mt-0.5" />
                  <p className="text-slate-700">{sol}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* STEDEN — intern linking voor GEO */}
        {service && (
          <section className="py-10 bg-slate-50">
            <div className="max-w-7xl mx-auto px-4">
              <h2 className="text-xl font-bold text-slate-900 mb-2">{problem.title} — Direct hulp per stad</h2>
              <p className="text-slate-600 text-sm mb-5">Onze spoedvakmannen zijn actief in heel België. Klik op uw stad voor lokale info.</p>
              <div className="flex flex-wrap gap-2">
                {BELGIAN_CITIES.map(city => (
                  <Link key={city.slug} to={beRoute(`/spoed-${service.slug}/${city.slug}`)}
                    className="px-3 py-1.5 bg-white border border-slate-200 rounded-full text-sm hover:bg-[#FF4500] hover:text-white hover:border-[#FF4500] transition-all">
                    {service.name} {city.name}
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* GERELATEERDE PROBLEMEN — interne linking */}
        {problem.relatedProblems?.length > 0 && (
          <section className="py-8 bg-white border-t">
            <div className="max-w-7xl mx-auto px-4">
              <h3 className="font-bold text-slate-700 mb-3">Gerelateerde spoedproblemen</h3>
              <div className="flex flex-wrap gap-2">
                {problem.relatedProblems.map(rSlug => {
                  const rProblem = BELGIAN_PROBLEMS[rSlug];
                  return rProblem ? (
                    <Link key={rSlug} to={beRoute(`/${rSlug}`)} className="px-4 py-2 bg-slate-50 border border-slate-200 rounded-full text-sm font-medium hover:border-[#FF4500] hover:text-[#FF4500] transition-all">
                      {rProblem.title}
                    </Link>
                  ) : null;
                })}
              </div>
            </div>
          </section>
        )}

        {/* CTA FINAL */}
        <section className="py-14 bg-[#FF4500]">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-black text-white mb-2">Hulp nodig? Bel nu — ook 's nachts!</h2>
            <p className="text-white/90 mb-6">24/7 beschikbaar — heel België — binnen 45 minuten</p>
            <a href={`tel:${BE_CONFIG.contact.phone}`} className="inline-flex items-center justify-center gap-2 bg-white text-[#FF4500] px-10 py-4 rounded-full font-black text-2xl hover:bg-slate-100">
              <Phone className="w-7 h-7" /> {BE_CONFIG.contact.phoneDisplay}
            </a>
            <p className="text-white/70 text-sm mt-4">Geen voorrijkosten • Vaste prijs • Erkend & verzekerd</p>
          </div>
        </section>

        <footer className="bg-slate-900 text-slate-400 py-6">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
            <Link to={beRoute("/")} className="text-white font-bold">SOSPro<span className="text-[#FF4500]">.be</span></Link>
            <div className="flex gap-4">
              {BELGIAN_SERVICES.filter(s => s.slug !== "slotenmaker").map(s => (
                <Link key={s.slug} to={beRoute(`/dienst/${s.slug}`)} className="hover:text-white">Spoed {s.name}</Link>
              ))}
            </div>
            <p>© 2026 SOSPro.be — 24/7 Spoed België</p>
          </div>
        </footer>
      </div>
    </>
  );
}
