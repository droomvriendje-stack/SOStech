import { useState, useRef, useEffect } from "react";
import { Phone, PhoneOff, Loader2 } from "lucide-react";
import axios from "axios";
import { Device } from "@twilio/voice-sdk";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

/**
 * "Bel nu" knop - gratis internetoproep (WebRTC via Twilio Voice SDK).
 *
 * Werking:
 * 1. Haalt een kortlevend Access Token op bij /api/voice/token
 * 2. Maakt een Twilio Device (= "softphone" in de browser)
 * 3. Belt naar `target` (bv. "vakman_123" of leeg = centrale spoedlijn)
 *
 * Props:
 *  - target: identity van de vakman om te bellen (optioneel)
 *  - identity: wie de beller is (default "klant")
 *  - label: tekst op de knop
 *  - className: extra Tailwind classes
 */
export default function CallButton({ target = "", identity = "klant", label = "Bel nu (gratis)", className = "" }) {
  const [status, setStatus] = useState("idle"); // idle | connecting | ringing | active | error
  const [error, setError] = useState("");
  const deviceRef = useRef(null);
  const callRef = useRef(null);

  useEffect(() => {
    return () => {
      // Cleanup bij unmount
      if (callRef.current) callRef.current.disconnect();
      if (deviceRef.current) deviceRef.current.destroy();
    };
  }, []);

  const startCall = async () => {
    setError("");
    setStatus("connecting");
    try {
      // 1. Token ophalen van backend
      const { data } = await axios.get(`${API}/voice/token`, {
        params: { identity: `${identity}_${Math.floor(Math.random() * 100000)}` }
      });

      // 2. Device aanmaken
      const device = new Device(data.token, { logLevel: "error" });
      deviceRef.current = device;

      device.on("error", (e) => {
        console.error("Twilio device error:", e);
        setError(e.message || "Verbindingsfout");
        setStatus("error");
      });

      await device.register();

      // 3. Oproep starten - "To" param bepaalt routing in /api/voice/twiml
      const call = await device.connect({ params: { To: target || "" } });
      callRef.current = call;

      setStatus("ringing");

      call.on("accept", () => setStatus("active"));
      call.on("disconnect", () => {
        setStatus("idle");
        callRef.current = null;
      });
      call.on("cancel", () => setStatus("idle"));
      call.on("error", (e) => {
        setError(e.message || "Oproepfout");
        setStatus("error");
      });
    } catch (e) {
      console.error(e);
      setError(
        e?.response?.status === 503
          ? "Bellen is nog niet geconfigureerd."
          : "Kon geen verbinding maken. Check je microfoon-toestemming."
      );
      setStatus("error");
    }
  };

  const endCall = () => {
    if (callRef.current) callRef.current.disconnect();
    if (deviceRef.current) deviceRef.current.destroy();
    deviceRef.current = null;
    callRef.current = null;
    setStatus("idle");
  };

  if (status === "active" || status === "ringing" || status === "connecting") {
    return (
      <button
        onClick={endCall}
        className={`flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-md font-medium hover:bg-slate-800 transition-colors ${className}`}
      >
        {status === "connecting" && <Loader2 className="w-4 h-4 animate-spin" />}
        {status === "ringing" && <Loader2 className="w-4 h-4 animate-spin" />}
        {status === "active" && <PhoneOff className="w-4 h-4" />}
        <span>
          {status === "connecting" && "Verbinden..."}
          {status === "ringing" && "Bellen..."}
          {status === "active" && "Hang op"}
        </span>
      </button>
    );
  }

  return (
    <div>
      <button
        onClick={startCall}
        className={`flex items-center gap-2 bg-[#FF4500] text-white px-4 py-2 rounded-md font-medium hover:bg-[#CC3700] transition-colors ${className}`}
      >
        <Phone className="w-4 h-4" />
        <span>{label}</span>
      </button>
      {status === "error" && error && (
        <p className="text-xs text-red-500 mt-1 max-w-[220px]">{error}</p>
      )}
    </div>
  );
}
