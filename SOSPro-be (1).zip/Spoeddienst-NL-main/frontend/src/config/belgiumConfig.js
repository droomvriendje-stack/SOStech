// Belgian Configuration for SOSPro.be
// SEO/SEA/GEO/GEA geoptimaliseerd om Homedeal.be, spoedservices.be en werkspot.be te verslaan

const IS_STANDALONE_BE = process.env.REACT_APP_COUNTRY === "BE";
export const getRoutePrefix = () => IS_STANDALONE_BE ? "" : "/be";
export const beRoute = (path) => {
  const prefix = getRoutePrefix();
  if (path === "/" || path === "") return prefix || "/";
  return `${prefix}${path}`;
};

export const BE_CONFIG = {
  country: "België",
  countryCode: "BE",
  currency: "EUR",
  phonePrefix: "+32",
  domain: "sospro.be",
  contact: {
    phone: "+3238084747",
    phoneDisplay: "03 808 47 47",
    email: "info@sospro.be",
    emergencyLine: "03 808 47 47",
    whatsapp: "+3238084747"
  },
  seo: {
    siteName: "SOSPro.be",
    titleSuffix: " | SOSPro.be — 24/7 Spoed België",
    description: "24/7 spoedelektricien & spoedloodgieter in heel België. Binnen 45 min ter plaatse. ✓ Erkend ✓ Vaste prijs ✓ Geen voorrijkosten. Bel: 03 808 47 47"
  },
  usp: [
    "Binnen 45 minuten ter plaatse",
    "24/7 — ook weekends & feestdagen",
    "Vaste prijs, geen verrassingen",
    "Erkende & verzekerde vakmannen",
    "Geen voorrijkosten",
    "Tevredenheidsgarantie"
  ],
  pricing: {
    elektricien: { dag: 89, spoed: 129, nacht: 149 },
    loodgieter:  { dag: 89, spoed: 119, nacht: 139 },
    slotenmaker: { dag: 79, spoed: 109, nacht: 129 }
  }
};

// 55+ Belgische steden — uitgebreid voor maximale GEO-dekking
export const BELGIAN_CITIES = [
  // Antwerpen provincie
  { name: "Antwerpen", slug: "antwerpen", province: "Antwerpen", isCapital: true, lat: 51.2194, lng: 4.4025, nearby: ["Berchem","Borgerhout","Deurne","Hoboken","Merksem","Wilrijk","Mortsel","Edegem","Kontich"] },
  { name: "Berchem", slug: "berchem", province: "Antwerpen", parent: "Antwerpen", lat: 51.1935, lng: 4.4263 },
  { name: "Borgerhout", slug: "borgerhout", province: "Antwerpen", parent: "Antwerpen", lat: 51.2129, lng: 4.4462 },
  { name: "Deurne", slug: "deurne", province: "Antwerpen", parent: "Antwerpen", lat: 51.2250, lng: 4.4633 },
  { name: "Ekeren", slug: "ekeren", province: "Antwerpen", parent: "Antwerpen", lat: 51.2833, lng: 4.4167 },
  { name: "Hoboken", slug: "hoboken", province: "Antwerpen", parent: "Antwerpen", lat: 51.1833, lng: 4.3667 },
  { name: "Merksem", slug: "merksem", province: "Antwerpen", parent: "Antwerpen", lat: 51.2500, lng: 4.4333 },
  { name: "Wilrijk", slug: "wilrijk", province: "Antwerpen", parent: "Antwerpen", lat: 51.1667, lng: 4.3833 },
  { name: "Mortsel", slug: "mortsel", province: "Antwerpen", lat: 51.1667, lng: 4.4500 },
  { name: "Edegem", slug: "edegem", province: "Antwerpen", lat: 51.1500, lng: 4.4333 },
  { name: "Kontich", slug: "kontich", province: "Antwerpen", lat: 51.1333, lng: 4.4500 },
  { name: "Schoten", slug: "schoten", province: "Antwerpen", lat: 51.2667, lng: 4.5000 },
  { name: "Brasschaat", slug: "brasschaat", province: "Antwerpen", lat: 51.2833, lng: 4.4833 },
  { name: "Kapellen", slug: "kapellen", province: "Antwerpen", lat: 51.3167, lng: 4.4333 },
  { name: "Wommelgem", slug: "wommelgem", province: "Antwerpen", lat: 51.2167, lng: 4.5167 },
  { name: "Mechelen", slug: "mechelen", province: "Antwerpen", lat: 51.0281, lng: 4.4806 },
  { name: "Turnhout", slug: "turnhout", province: "Antwerpen", lat: 51.3219, lng: 4.9500 },
  { name: "Lier", slug: "lier", province: "Antwerpen", lat: 51.1333, lng: 4.5667 },
  { name: "Heist-op-den-Berg", slug: "heist-op-den-berg", province: "Antwerpen", lat: 51.0833, lng: 4.7167 },
  // Oost-Vlaanderen
  { name: "Gent", slug: "gent", province: "Oost-Vlaanderen", isCapital: true, lat: 51.0543, lng: 3.7174, nearby: ["Sint-Amandsberg","Ledeberg","Gentbrugge","Wondelgem","Mariakerke"] },
  { name: "Sint-Niklaas", slug: "sint-niklaas", province: "Oost-Vlaanderen", lat: 51.1667, lng: 4.1333 },
  { name: "Aalst", slug: "aalst", province: "Oost-Vlaanderen", lat: 50.9333, lng: 4.0333 },
  { name: "Dendermonde", slug: "dendermonde", province: "Oost-Vlaanderen", lat: 51.0333, lng: 4.1000 },
  { name: "Lokeren", slug: "lokeren", province: "Oost-Vlaanderen", lat: 51.1000, lng: 3.9833 },
  { name: "Wetteren", slug: "wetteren", province: "Oost-Vlaanderen", lat: 51.0000, lng: 3.8833 },
  // West-Vlaanderen
  { name: "Brugge", slug: "brugge", province: "West-Vlaanderen", isCapital: true, lat: 51.2093, lng: 3.2247, nearby: ["Sint-Michiels","Sint-Andries","Assebroek","Koolkerke"] },
  { name: "Oostende", slug: "oostende", province: "West-Vlaanderen", lat: 51.2307, lng: 2.9161 },
  { name: "Kortrijk", slug: "kortrijk", province: "West-Vlaanderen", lat: 50.8278, lng: 3.2625 },
  { name: "Roeselare", slug: "roeselare", province: "West-Vlaanderen", lat: 50.9453, lng: 3.1228 },
  { name: "Knokke-Heist", slug: "knokke-heist", province: "West-Vlaanderen", lat: 51.3536, lng: 3.3000 },
  { name: "Blankenberge", slug: "blankenberge", province: "West-Vlaanderen", lat: 51.3094, lng: 3.1314 },
  // Vlaams-Brabant
  { name: "Leuven", slug: "leuven", province: "Vlaams-Brabant", isCapital: true, lat: 50.8798, lng: 4.7005, nearby: ["Heverlee","Kessel-Lo","Wijgmaal","Wilsele"] },
  { name: "Vilvoorde", slug: "vilvoorde", province: "Vlaams-Brabant", lat: 50.9281, lng: 4.4214 },
  { name: "Aarschot", slug: "aarschot", province: "Vlaams-Brabant", lat: 50.9833, lng: 4.8333 },
  { name: "Tienen", slug: "tienen", province: "Vlaams-Brabant", lat: 50.8000, lng: 4.9333 },
  { name: "Diest", slug: "diest", province: "Vlaams-Brabant", lat: 50.9833, lng: 5.0500 },
  { name: "Halle", slug: "halle", province: "Vlaams-Brabant", lat: 50.7333, lng: 4.2333 },
  // Brussels Gewest
  { name: "Brussel", slug: "brussel", province: "Brussels Hoofdstedelijk Gewest", isCapital: true, lat: 50.8503, lng: 4.3517, nearby: ["Elsene","Ukkel","Etterbeek","Sint-Gillis","Anderlecht","Molenbeek"] },
  { name: "Schaarbeek", slug: "schaarbeek", province: "Brussels Hoofdstedelijk Gewest", lat: 50.8683, lng: 4.3786 },
  { name: "Anderlecht", slug: "anderlecht", province: "Brussels Hoofdstedelijk Gewest", lat: 50.8403, lng: 4.3017 },
  { name: "Sint-Jans-Molenbeek", slug: "sint-jans-molenbeek", province: "Brussels Hoofdstedelijk Gewest", lat: 50.8564, lng: 4.3261 },
  { name: "Elsene", slug: "elsene", province: "Brussels Hoofdstedelijk Gewest", lat: 50.8244, lng: 4.3732 },
  { name: "Ukkel", slug: "ukkel", province: "Brussels Hoofdstedelijk Gewest", lat: 50.8017, lng: 4.3375 },
  { name: "Etterbeek", slug: "etterbeek", province: "Brussels Hoofdstedelijk Gewest", lat: 50.8389, lng: 4.3947 },
  { name: "Sint-Gillis", slug: "sint-gillis", province: "Brussels Hoofdstedelijk Gewest", lat: 50.8283, lng: 4.3408 },
  // Limburg
  { name: "Hasselt", slug: "hasselt", province: "Limburg", isCapital: true, lat: 50.9311, lng: 5.3378 },
  { name: "Genk", slug: "genk", province: "Limburg", lat: 50.9667, lng: 5.4833 },
  { name: "Sint-Truiden", slug: "sint-truiden", province: "Limburg", lat: 50.8167, lng: 5.1833 },
  { name: "Beringen", slug: "beringen", province: "Limburg", lat: 51.0500, lng: 5.2167 },
  { name: "Tongeren", slug: "tongeren", province: "Limburg", lat: 50.7800, lng: 5.4647 },
  // Wallonië (FR)
  { name: "Luik", slug: "luik", province: "Luik (Liège)", isCapital: true, lat: 50.6325, lng: 5.5797, nearby: ["Ans","Seraing","Herstal","Beyne-Heusay"] },
  { name: "Namen", slug: "namen", province: "Namen (Namur)", isCapital: true, lat: 50.4669, lng: 4.8676 },
  { name: "Charleroi", slug: "charleroi", province: "Henegouwen (Hainaut)", lat: 50.4108, lng: 4.4446 },
  { name: "Bergen", slug: "bergen", province: "Henegouwen (Hainaut)", lat: 50.4542, lng: 3.9563 },


  // Zaventem — HOOFDKANTOOR, hoogste SEO/SEA/GEO prioriteit
  { name: "Zaventem", slug: "zaventem", province: "Vlaams-Brabant", isCapital: true, isHQ: true, lat: 50.8833, lng: 4.4667, nearby: ["Sterrebeek","Sint-Stevens-Woluwe","Nossegem","Diegem"] },
  { name: "Sterrebeek", slug: "sterrebeek", province: "Vlaams-Brabant", parent: "Zaventem", lat: 50.8667, lng: 4.4833 },
  { name: "Sint-Stevens-Woluwe", slug: "sint-stevens-woluwe", province: "Vlaams-Brabant", parent: "Zaventem", lat: 50.8833, lng: 4.4500 },
  { name: "Nossegem", slug: "nossegem", province: "Vlaams-Brabant", parent: "Zaventem", lat: 50.8833, lng: 4.4833 },
  { name: "Diegem", slug: "diegem", province: "Vlaams-Brabant", parent: "Zaventem", lat: 50.8833, lng: 4.4333 },
  { name: "Melsbroek", slug: "melsbroek", province: "Vlaams-Brabant", lat: 50.9000, lng: 4.4833 },
  { name: "Kraainem", slug: "kraainem", province: "Vlaams-Brabant", lat: 50.8500, lng: 4.4667 },
  { name: "Wezembeek-Oppem", slug: "wezembeek-oppem", province: "Vlaams-Brabant", lat: 50.8500, lng: 4.4833 },
  { name: "Machelen", slug: "machelen", province: "Vlaams-Brabant", lat: 50.9000, lng: 4.4333 },
  { name: "Steenokkerzeel", slug: "steenokkerzeel", province: "Vlaams-Brabant", lat: 50.9167, lng: 4.5167 },
  { name: "Kortenberg", slug: "kortenberg", province: "Vlaams-Brabant", lat: 50.8833, lng: 4.5500 },
  { name: "Tervuren", slug: "tervuren", province: "Vlaams-Brabant", lat: 50.8167, lng: 4.5167 },
  { name: "Kampenhout", slug: "kampenhout", province: "Vlaams-Brabant", lat: 50.9333, lng: 4.5667 },
  { name: "Grimbergen", slug: "grimbergen", province: "Vlaams-Brabant", lat: 50.9333, lng: 4.3667 },
  { name: "Zemst", slug: "zemst", province: "Vlaams-Brabant", lat: 50.9833, lng: 4.4667 },
  // Leuven deelgemeenten — SEO dominantie in Vlaams-Brabant
  { name: "Heverlee", slug: "heverlee", province: "Vlaams-Brabant", parent: "Leuven", lat: 50.8567, lng: 4.6983 },
  { name: "Kessel-Lo", slug: "kessel-lo", province: "Vlaams-Brabant", parent: "Leuven", lat: 50.8997, lng: 4.7236 },
  { name: "Wilsele", slug: "wilsele", province: "Vlaams-Brabant", parent: "Leuven", lat: 50.9167, lng: 4.7000 },
  { name: "Wijgmaal", slug: "wijgmaal", province: "Vlaams-Brabant", parent: "Leuven", lat: 50.9167, lng: 4.6667 },
  { name: "Herent", slug: "herent", province: "Vlaams-Brabant", lat: 50.9167, lng: 4.6667 },
  { name: "Rotselaar", slug: "rotselaar", province: "Vlaams-Brabant", lat: 50.9500, lng: 4.7167 },
  { name: "Oud-Heverlee", slug: "oud-heverlee", province: "Vlaams-Brabant", lat: 50.8167, lng: 4.6667 },
  { name: "Bierbeek", slug: "bierbeek", province: "Vlaams-Brabant", lat: 50.8333, lng: 4.7667 },
  { name: "Bertem", slug: "bertem", province: "Vlaams-Brabant", lat: 50.8667, lng: 4.6333 },
  { name: "Holsbeek", slug: "holsbeek", province: "Vlaams-Brabant", lat: 50.9000, lng: 4.7833 },
  { name: "Lubbeek", slug: "lubbeek", province: "Vlaams-Brabant", lat: 50.8667, lng: 4.8333 },
  { name: "Korbeek-Lo", slug: "korbeek-lo", province: "Vlaams-Brabant", parent: "Bierbeek", lat: 50.8500, lng: 4.7333 },
  { name: "Leuze-en-Hainaut", slug: "leuze-en-hainaut", province: "Henegouwen (Hainaut)", lat: 50.5968, lng: 3.6193 }
];

// Diensten — Combo A (core) + uitbreidbaar
export const BELGIAN_SERVICES = [
  {
    slug: "elektricien",
    name: "Elektricien",
    nameFR: "Électricien",
    icon: "zap",
    color: "from-yellow-400 to-orange-500",
    tagline: "Stroomstoring? Kortsluiting? Binnen 45 min ter plaatse.",
    description: "24/7 erkende spoedelektricien in België. Stroomstoring, kortsluiting, differentieel — direct opgelost.",
    priceFrom: 89,
    priceSpoed: 129,
    keywords: ["spoed elektricien","stroomstoring","kortsluiting","elektricien 24/7","erkend elektricien België"]
  },
  {
    slug: "loodgieter",
    name: "Loodgieter",
    nameFR: "Plombier",
    icon: "droplet",
    color: "from-blue-500 to-blue-600",
    tagline: "Waterlek? Verstopping? Wij stoppen de schade.",
    description: "24/7 spoedloodgieter in België. Lekkages, verstoppingen, boiler defect — snel & vakkundig opgelost.",
    priceFrom: 89,
    priceSpoed: 119,
    keywords: ["spoed loodgieter","lekkage","waterlek","loodgieter 24/7","verstopping België"]
  },
  {
    slug: "slotenmaker",
    name: "Slotenmaker",
    nameFR: "Serrurier",
    icon: "key",
    color: "from-slate-600 to-slate-700",
    tagline: "Buitengesloten? Slot defect? Direct hulp.",
    description: "24/7 slotenmaker in België. Deur openen, slot vervangen, inbraakbeveiliging — binnen 20 min.",
    priceFrom: 79,
    priceSpoed: 109,
    keywords: ["slotenmaker","buitengesloten","slot vervangen","deur openen België","24/7 slotenmaker"]
  }
];

// Probleempagina's — uitgebreid met Combo A focus (elektricien + loodgieter)
export const BELGIAN_PROBLEMS = {
  "lekkage-spoed": {
    title: "Spoed Lekkage & Waterlek België",
    metaTitle: "Lekkage Spoed België | 24/7 Loodgieter Binnen 45 Min | SOSPro.be",
    metaDescription: "Waterlekkage in België? ✓ 24/7 spoedloodgieter ✓ Binnen 45 minuten ter plaatse ✓ Geen voorrijkosten ✓ Vaste prijs. Stop waterschade nu. Bel: 03 808 47 47",
    service: "loodgieter",
    icon: "droplet",
    priceFrom: "€89",
    heroText: "Waterlekkage? Elke minuut kost u meer — Bel Nu!",
    description: "Een waterlekkage kan in luttele minuten voor honderden euro's schade zorgen. Onze erkende spoedloodgieters zijn 24/7 inzetbaar in heel België en stoppen het lek vakkundig.",
    urgencyTip: "Draai onmiddellijk de hoofdkraan dicht (kelder of meterkast). Bel dan 03 808 47 47.",
    symptoms: [
      "Waterleiding gebarsten of gesprongen",
      "Lekkage aan radiator of cv-installatie",
      "Waterlekkage van bovenliggende verdieping",
      "Vochtige of natte muren/plafonds",
      "Waterlek aan kraan of toilet",
      "Onderstromende kelder"
    ],
    solutions: [
      "Spoedafsluitng & lekreparatie",
      "Lekdetectie met professioneel materiaal",
      "Vervanging beschadigde leidingen",
      "Waterschade beperking & noodinterventie"
    ],
    relatedProblems: ["toilet-verstopt-spoed","stroomstoring-spoed"],
    relatedService: "loodgieter"
  },
  "toilet-verstopt-spoed": {
    title: "Toilet & WC Verstopt — Spoed Ontstopping België",
    metaTitle: "Toilet Verstopt Spoed België | 24/7 Ontstopping | SOSPro.be",
    metaDescription: "Toilet of WC verstopt in België? ✓ 24/7 spoedloodgieter ✓ Professionele hogedrukontstopping ✓ Binnen 45 min ✓ Vaste prijs. Bel: 03 808 47 47",
    service: "loodgieter",
    icon: "droplet",
    priceFrom: "€89",
    heroText: "Toilet verstopt? Direct professioneel ontstopt in België!",
    description: "Een verstopt toilet of riool kan snel escaleren. Onze loodgieters gebruiken professioneel hogedrukmmateriaal en ontstoppen elk type verstopping snel en grondig.",
    urgencyTip: "Spoel niet opnieuw door — dit vergroot de overstroming. Bel direct 03 808 47 47.",
    symptoms: [
      "Toilet loopt vol bij doorspoelen",
      "Vloer rondom toilet staat blank",
      "Meerdere afvoeren tegelijk verstopt",
      "Bubbels in toilet of bad",
      "Onaangename geur uit riool",
      "Rioolwater loopt terug"
    ],
    solutions: [
      "Hogedrukontstopping (jet-spray)",
      "Verstopte rioollijn vrijmaken",
      "Camera-inspectie riool",
      "Vervanging verzakte/gebarsten rioolleidingen"
    ],
    relatedProblems: ["lekkage-spoed","stroomstoring-spoed"],
    relatedService: "loodgieter"
  },
  "stroomstoring-spoed": {
    title: "Stroomstoring & Stroomuitval — Spoed Elektricien België",
    metaTitle: "Stroomstoring Spoed België | 24/7 Elektricien | SOSPro.be",
    metaDescription: "Stroomstoring of stroomuitval in België? ✓ 24/7 erkende spoedelektricien ✓ Binnen 45 min ✓ AREI-conform ✓ Vaste prijs. Bel: 03 808 47 47",
    service: "elektricien",
    icon: "zap",
    priceFrom: "€89",
    heroText: "Geen stroom? Onze elektricien lost het op — ook 's nachts!",
    description: "Stroomstoring in huis of appartement? Onze erkende AREI-conforme elektriciens sporen het probleem snel op en herstellen uw installatie veilig en conform de Belgische normen.",
    urgencyTip: "Schakel het hoofdgroepje uit op de meterkast en ontkoppel gevoelige apparaten. Bel dan 03 808 47 47.",
    symptoms: [
      "Volledige stroomuitval in de woning",
      "Differentieel of zekering slaat steeds af",
      "Stroom weg in deel van de woning",
      "Vonken of brandgeur bij stopcontact",
      "Meterkast warm of zoemend",
      "Stroom weg na onweer of bliksem"
    ],
    solutions: [
      "Diagnose & opsporing oorzaak stroomstoring",
      "Herstel beschadigde bedrading",
      "Vervanging defecte differentieel/zekeringen",
      "Veiligheidscontrole volledige installatie (AREI)"
    ],
    relatedProblems: ["kortsluiting-spoed","lekkage-spoed"],
    relatedService: "elektricien"
  },
  "kortsluiting-spoed": {
    title: "Kortsluiting Spoed — Erkende Elektricien België",
    metaTitle: "Kortsluiting Spoed België | 24/7 Elektricien | SOSPro.be",
    metaDescription: "Kortsluiting in België? ✓ BRANDGEVAAR — direct actie vereist ✓ 24/7 erkende elektricien ✓ Binnen 45 min ✓ AREI-conform. Bel NU: 03 808 47 47",
    service: "elektricien",
    icon: "zap",
    priceFrom: "€89",
    heroText: "Kortsluiting = Brandgevaar — Bel Onmiddellijk!",
    description: "Kortsluiting is een van de meest ernstige elektrische noodsituaties. Wacht niet — brandgevaar is reëel. Onze erkende elektriciens reageren dag en nacht.",
    urgencyTip: "DRINGEND: Schakel het hoofdgroepje UIT. Verwijder brandbare materialen bij de meterkast. Bel 03 808 47 47.",
    symptoms: [
      "Zekering of differentieel slaat direct af bij inschakelen",
      "Brandgeur of rookontwikkeling",
      "Bruine/zwarte verkleuringen op stopcontacten",
      "Knetterend of zoemend geluid in muren",
      "Stopcontact of schakelaar warm bij aanraking",
      "Stroom werkt niet meer in deel van het huis"
    ],
    solutions: [
      "Spoeddiagnose kortsluiting & opsporing",
      "Vervanging beschadigde bedrading/kabels",
      "Herstelling/vervanging meterkast componenten",
      "Volledige veiligheidsaudit installatie"
    ],
    relatedProblems: ["stroomstoring-spoed","lekkage-spoed"],
    relatedService: "elektricien"
  }
};

export const SERVICE_ICONS = { elektricien: "⚡", loodgieter: "🔧", slotenmaker: "🔐" };

export default { config: BE_CONFIG, cities: BELGIAN_CITIES, services: BELGIAN_SERVICES, problems: BELGIAN_PROBLEMS };
