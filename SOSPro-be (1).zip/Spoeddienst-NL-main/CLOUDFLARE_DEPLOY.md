# SOSPro.be — Deployen via Cloudflare

## Architectuur

Cloudflare Pages kan **alleen statische bestanden** serveren (de React frontend).
De backend (FastAPI + MongoDB + Mollie) is een langlevende Python-server en
**kan niet** op Cloudflare Pages of standaard Workers draaien (geen MongoDB
socket-support, geen lang draaiende processen).

Aanbevolen opzet:

```
sospro.be          -> Cloudflare Pages   (frontend, React build)
api.sospro.be      -> Railway / Fly.io / Render  (FastAPI backend + MongoDB)
```

Cloudflare blijft de DNS-beheerder voor beide subdomeinen (oranje cloud = proxy aan).

---

## 1. Frontend op Cloudflare Pages

### Build instellingen (Pages dashboard -> project -> Settings -> Builds)

| Instelling              | Waarde                          |
|-------------------------|----------------------------------|
| Framework preset         | Create React App                |
| Build command            | `npm run build`                 |
| Build output directory   | `build`                          |
| Root directory            | `frontend`                       |
| Node version              | 20 (zet via `NODE_VERSION=20` env var) |

### Environment variables (Pages -> Settings -> Environment variables)

Voor **Production**:
```
REACT_APP_COUNTRY=BE
REACT_APP_BACKEND_URL=https://api.sospro.be
NODE_VERSION=20
CI=false
```

### Meegeleverde Cloudflare configbestanden

- `frontend/public/_redirects` — SPA-fallback zodat alle React Router paden
  (bijv. `/dienst/elektricien`, `/spoed-loodgieter/antwerpen`) naar
  `index.html` gaan en niet op een 404 van Cloudflare landen.
- `frontend/public/_headers` — security headers (HSTS, X-Frame-Options,
  Referrer-Policy) en caching: hashed `/static/*` bestanden 1 jaar cachen,
  `index.html` altijd revalideren zodat updates direct live staan.

### Custom domain

1. Pages project -> Custom domains -> voeg `sospro.be` en `www.sospro.be` toe.
2. Cloudflare maakt automatisch de juiste CNAME/records aan (zelfde account = automatisch).
3. SSL/TLS staat standaard op "Full" via Pages — geen actie nodig.

---

## 2. Backend (api.sospro.be)

Kies één van: **Railway**, **Render**, of **Fly.io** (alle drie ondersteunen
Python/FastAPI + draaiende processen, in tegenstelling tot Cloudflare Pages).

1. Deploy de `backend/` map (heeft al `requirements.txt`).
2. Start command: `uvicorn server:app --host 0.0.0.0 --port $PORT`
3. Zet environment variables daar (zelfde als `.env.production`):
   - `MONGODB_URI`
   - `MOLLIE_API_KEY`
   - `SMTP_*`
   - `API_BASE_URL=https://api.sospro.be`
4. Zodra het een publieke URL heeft (bv. `sospro-api.up.railway.app`):
   - Ga naar Cloudflare DNS voor `sospro.be`
   - Voeg een **CNAME** record toe: `api` -> `sospro-api.up.railway.app`
   - Proxy status: **Proxied** (oranje cloud) voor DDoS-bescherming + caching

---

## 3. Cloudflare-specifieke instellingen (DNS dashboard)

| Record | Type  | Waarde                          | Proxy |
|--------|-------|----------------------------------|-------|
| `@`    | -     | (automatisch via Pages)          | ✅    |
| `www`  | -     | (automatisch via Pages)          | ✅    |
| `api`  | CNAME | backend host (Railway/Render/Fly)| ✅    |

### Aanbevolen Cloudflare-instellingen (SSL/TLS tab)
- SSL/TLS encryption mode: **Full (strict)**
- Always Use HTTPS: **Aan**
- Automatic HTTPS Rewrites: **Aan**
- Minimum TLS Version: **1.2**

### Caching
- Browser Cache TTL: Respect Existing Headers (onze `_headers` regelt dit al)
- Voor `/api/*` op `api.sospro.be`: cache **uitschakelen** via een Cache Rule
  (Rules -> Cache Rules -> "api.sospro.be/*" -> Bypass cache)

### Page Rules / Redirects
- `sospro.nl` (toekomstige NL-uitbreiding) -> los Pages-project of
  `REACT_APP_COUNTRY=NL` build, los van deze BE-deploy.

---

## 4. Checklist voor go-live

- [ ] `sospro.be` + `sospro.nl` geregistreerd bij DNS Belgium / SIDN, nameservers naar Cloudflare
- [ ] Backend live op `api.sospro.be` met echte MongoDB + Mollie API key
- [ ] Frontend Pages build slaagt met `REACT_APP_BACKEND_URL=https://api.sospro.be`
- [ ] `_redirects` en `_headers` aanwezig in `build/` output (controleer na build)
- [ ] SSL "Full (strict)" + "Always use HTTPS" actief
- [ ] Test alle Belgische routes (`/`, `/dienst/elektricien`, `/spoed-loodgieter/antwerpen`, `/boek`) — geen 404's
